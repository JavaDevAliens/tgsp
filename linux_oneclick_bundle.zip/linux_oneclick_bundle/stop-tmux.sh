#!/usr/bin/env bash

if [ -z "${BASH_VERSION:-}" ]; then
  if command -v bash >/dev/null 2>&1; then
    exec bash "$0" "$@"
  fi
  echo "ERROR: bash is required to run this script." >&2
  exit 1
fi

set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$APP_DIR"

SESSION_NAME="autoappnt"

echo "[autoappnt] Requesting soft stop..."
bash stop.sh || true

if command -v tmux >/dev/null 2>&1; then
  if tmux has-session -t "$SESSION_NAME" 2>/dev/null; then
    echo "[autoappnt] Killing tmux session: $SESSION_NAME"
    tmux kill-session -t "$SESSION_NAME" || true
  fi
fi

echo "[autoappnt] Stopped."
