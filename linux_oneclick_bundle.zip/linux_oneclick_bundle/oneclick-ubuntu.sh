#!/usr/bin/env bash

if [ -z "${BASH_VERSION:-}" ]; then
  if command -v bash >/dev/null 2>&1; then
    exec bash "$0" "$@"
  fi
  echo "ERROR: bash is required to run this script." >&2
  exit 1
fi

set -euo pipefail

# One-click Ubuntu deploy (24/7) for AutoAppnt monitor + optional scraping.
#
# What it does:
# - Ensures you're running from ~/autoappnt
# - Optionally installs Ubuntu packages (python3/venv/pip)
# - Creates venv + installs Python deps
# - Optionally installs scraper deps + Playwright Chromium
# - Creates config.json from template if missing
# - Validates config.json (won't start service with placeholder creds)
# - Installs + starts systemd user service
# - Enables lingering so it runs after logout

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_DIR="$HOME/autoappnt"

if [ "$APP_DIR" != "$TARGET_DIR" ]; then
  echo "ERROR: One-click expects this folder at: $TARGET_DIR" >&2
  echo "Move it first, e.g.:" >&2
  echo "  mv \"$APP_DIR\" \"$TARGET_DIR\"" >&2
  exit 1
fi

cd "$APP_DIR"

echo "[autoappnt] One-click Ubuntu deploy starting..."

ARCH="$(uname -m || true)"
case "$ARCH" in
  x86_64|aarch64|arm64) ;; 
  *)
    echo "[autoappnt] WARNING: Architecture '$ARCH' may not be supported by Playwright Chromium." >&2
    echo "           Recommended: x86_64 or aarch64." >&2
    ;;
esac

# Defaults: install Ubuntu packages, scraper deps, and Playwright browser.
AUTOAPPNT_APT="${AUTOAPPNT_APT:-1}"
AUTOAPPNT_SCRAPER="${AUTOAPPNT_SCRAPER:-1}"
AUTOAPPNT_INSTALL_PLAYWRIGHT_BROWSERS="${AUTOAPPNT_INSTALL_PLAYWRIGHT_BROWSERS:-1}"
AUTOAPPNT_INSTALL_PLAYWRIGHT_DEPS="${AUTOAPPNT_INSTALL_PLAYWRIGHT_DEPS:-1}"
AUTOAPPNT_ONECLICK_ENABLE_PLAYWRIGHT_CONFIG="${AUTOAPPNT_ONECLICK_ENABLE_PLAYWRIGHT_CONFIG:-1}"

export AUTOAPPNT_APT AUTOAPPNT_SCRAPER AUTOAPPNT_INSTALL_PLAYWRIGHT_BROWSERS AUTOAPPNT_INSTALL_PLAYWRIGHT_DEPS

bash setup.sh

# If Playwright is installed, optionally flip config to use it.
if [ "$AUTOAPPNT_ONECLICK_ENABLE_PLAYWRIGHT_CONFIG" = "1" ]; then
  if [ -f config.json ]; then
  # shellcheck disable=SC1091
  source .venv/bin/activate
  python - <<'PY'
import json
from pathlib import Path

p = Path('config.json')
data = json.loads(p.read_text(encoding='utf-8'))

scrape_engine = (data.get('scrape_engine') or '').strip().lower()
if scrape_engine in ('', 'requests'):
  data['scrape_engine'] = 'playwright'

if data.get('scrape_include_screenshot') in (False, None):
  data['scrape_include_screenshot'] = True

p.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
print('[autoappnt] Updated config.json for Playwright (scrape_engine/playwright + screenshots enabled)')
PY
  fi
fi

# Validate config.json before starting service.
if [ ! -f config.json ]; then
  echo "ERROR: config.json was not created." >&2
  exit 1
fi

python - <<'PY'
import json
from pathlib import Path

cfg = json.loads(Path('config.json').read_text(encoding='utf-8'))

api_id = cfg.get('api_id')
api_hash = cfg.get('api_hash')

def is_placeholder(v: object) -> bool:
  if v is None:
    return True
  if isinstance(v, str) and ('your_' in v.lower() or 'target_' in v.lower()):
    return True
  return False

ok = True
if not isinstance(api_id, int):
  ok = False
if not isinstance(api_hash, str) or len(api_hash.strip()) < 10 or is_placeholder(api_hash):
  ok = False

if not ok:
  print('[autoappnt] Config not ready. Edit config.json (api_id/api_hash/forward_target_channel_id), then run:')
  print('  bash install-user-service.sh')
  raise SystemExit(2)

print('[autoappnt] Config validation OK')
PY

# Prefer systemd user service when available; fall back to tmux for mobile/proot.
if command -v systemctl >/dev/null 2>&1 && systemctl --user show-environment >/dev/null 2>&1; then
  echo "[autoappnt] systemd user session detected; installing service."
  bash install-user-service.sh

  # Enable lingering for true 24/7 (needs sudo)
  echo "[autoappnt] Enabling linger (requires sudo)"
  if command -v sudo >/dev/null 2>&1; then
    sudo loginctl enable-linger "$USER"
  else
    loginctl enable-linger "$USER"
  fi

  echo "[autoappnt] One-click deploy complete."
  echo "Logs: journalctl --user -u autoappnt-monitor.service -f"
else
  echo "[autoappnt] systemd not available (common on mobile Ubuntu/proot). Using tmux runner instead."
  bash start-tmux.sh
  echo "[autoappnt] One-click deploy complete (tmux mode)."
  echo "[autoappnt] Logs: $HOME/autoappnt/channel_monitor_mobile.log"
fi
