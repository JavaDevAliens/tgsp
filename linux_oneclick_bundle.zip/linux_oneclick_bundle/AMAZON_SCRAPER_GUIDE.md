# Amazon Product Scraper - Usage Guide

## 🎯 What This Script Does:

Extracts complete product information from any Amazon product URL:
- ✅ Full page screenshot
- ✅ Product title
- ✅ High-resolution product image
- ✅ All prices (Current, MRP, Discount, You Save, EMI)

## 📝 How to Use:

### Method 1: Interactive Mode
```powershell
python amazon_scraper.py
```
Then enter the Amazon product URL when prompted.

### Method 2: Command Line
```powershell
python amazon_scraper.py "https://www.amazon.in/dp/B0XXXXXX"
```

## 📂 Output:

Creates a folder named `amazon_product_YYYYMMDD_HHMMSS` containing:
- `product_screenshot.png` - Full page screenshot
- `product_image.jpg` - High-res product image
- `product_info.txt` - Title, URL, and all prices

## 💡 Example:

```powershell
python amazon_scraper.py "https://www.amazon.in/dp/B0DM6D8JFW"
```

Output:
```
📦 AMAZON PRODUCT SUMMARY
📝 Title: Lifelong Stainless Steel Water Bottle 900ml...
💰 Pricing:
   • Current Price: ₹249
   • MRP (Original Price): ₹649
   • Discount: -62%
   • You Save: ₹400
📁 Files saved in: amazon_product_20251016_143025/
```

## 🚀 Ready to Use!

Just run the script and paste any Amazon product URL!
