#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if ! command -v systemctl >/dev/null 2>&1; then
  echo "ERROR: systemd/systemctl not found. Use tmux/nohup instead." >&2
  exit 1
fi

mkdir -p "$HOME/.config/systemd/user"

# Service assumes app lives at ~/autoappnt
TARGET_DIR="$HOME/autoappnt"
if [ "$APP_DIR" != "$TARGET_DIR" ]; then
  echo "[autoappnt] NOTE: systemd unit assumes app is in $TARGET_DIR" >&2
  echo "         Move/copy this folder to $TARGET_DIR, or edit autoappnt-monitor.service." >&2
fi

cp -f autoappnt-monitor.service "$HOME/.config/systemd/user/autoappnt-monitor.service"

systemctl --user daemon-reload
systemctl --user enable --now autoappnt-monitor.service

echo "[autoappnt] Enabled user service: autoappnt-monitor.service"
echo "[autoappnt] View logs: journalctl --user -u autoappnt-monitor.service -f"
echo "[autoappnt] IMPORTANT: to run 24/7 even when logged out, enable lingering:" 
echo "  sudo loginctl enable-linger $USER"
