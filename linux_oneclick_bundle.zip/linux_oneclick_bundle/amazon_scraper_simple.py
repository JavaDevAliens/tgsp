"""
Amazon Product Information Scraper (Simple Version)
Takes an Amazon product URL and extracts:
- Product title
- Product image
- All prices (current, original, discount)
"""

import requests
from bs4 import BeautifulSoup
import re
import os
from datetime import datetime
from PIL import Image
from io import BytesIO


class AmazonProductScraper:
    def __init__(self):
        """Initialize scraper with headers"""
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1'
        }
    
    def scrape_product(self, url):
        """Scrape Amazon product information"""
        try:
            print(f"\n📡 Fetching product page...")
            
            response = requests.get(url, headers=self.headers, timeout=15)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Create output folder
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            output_folder = f"amazon_product_{timestamp}"
            os.makedirs(output_folder, exist_ok=True)
            
            print(f"📁 Saving to folder: {output_folder}\n")
            
            # 1. Get product title
            title = self.get_title(soup)
            print(f"📝 Product Title:")
            print(f"   {title}\n")
            
            # 2. Get product image
            image_url = self.get_main_image(soup)
            if image_url:
                image_path = self.download_image(image_url, output_folder)
                if image_path:
                    print(f"✅ Product image saved: {image_path}\n")
            
            # 3. Get all prices
            prices = self.get_all_prices(soup)
            print(f"💰 Prices:")
            for price_type, price_value in prices.items():
                print(f"   • {price_type}: {price_value}")
            
            # Save all info to text file
            self.save_info(title, url, prices, image_url, output_folder)
            
            # Display summary
            self.display_summary(title, prices, image_url, output_folder)
            
            return {
                'title': title,
                'prices': prices,
                'image_url': image_url,
                'output_folder': output_folder
            }
            
        except Exception as e:
            print(f"❌ Error scraping product: {e}")
            import traceback
            traceback.print_exc()
            return None
    
    def get_title(self, soup):
        """Extract product title"""
        try:
            # Try multiple selectors
            title_elem = soup.find('span', {'id': 'productTitle'})
            if title_elem:
                return title_elem.text.strip()
            
            title_elem = soup.find('h1', {'id': 'title'})
            if title_elem:
                return title_elem.text.strip()
            
            return "Title not found"
        except:
            return "Title not found"
    
    def get_main_image(self, soup):
        """Extract main product image URL"""
        try:
            # Try to find main image
            img_elem = soup.find('img', {'id': 'landingImage'})
            if img_elem and img_elem.get('src'):
                img_url = img_elem['src']
                # Get high-res version
                img_url = re.sub(r'\._.*?_\.', '._AC_SL1500_.', img_url)
                return img_url
            
            # Alternative: find in image block
            img_block = soup.find('div', {'id': 'imageBlock'})
            if img_block:
                img_elem = img_block.find('img')
                if img_elem and img_elem.get('src'):
                    return img_elem['src']
            
            # Try data-old-hires attribute
            img_elem = soup.find('img', {'data-old-hires': True})
            if img_elem:
                return img_elem['data-old-hires']
            
            return None
        except:
            return None
    
    def get_all_prices(self, soup):
        """Extract all price information"""
        prices = {}
        
        try:
            # Current Price / Deal Price
            price_elem = soup.find('span', {'class': 'a-price-whole'})
            if price_elem:
                price_fraction = soup.find('span', {'class': 'a-price-fraction'})
                fraction_text = price_fraction.text if price_fraction else '00'
                prices['Current Price'] = f"₹{price_elem.text.strip()}{fraction_text}"
            else:
                # Alternative price selector
                price_elem = soup.find('span', {'id': 'priceblock_ourprice'})
                if price_elem:
                    prices['Current Price'] = price_elem.text.strip()
                else:
                    price_elem = soup.find('span', {'id': 'priceblock_dealprice'})
                    if price_elem:
                        prices['Current Price'] = price_elem.text.strip()
            
            # MRP / List Price
            mrp_elem = soup.find('span', {'class': 'a-price a-text-price'})
            if mrp_elem:
                mrp_text = mrp_elem.find('span', {'class': 'a-offscreen'})
                if mrp_text:
                    prices['MRP (Original Price)'] = mrp_text.text.strip()
            
            # Alternative MRP
            if 'MRP (Original Price)' not in prices:
                mrp_elem = soup.find('span', {'class': 'a-text-price'})
                if mrp_elem:
                    offscreen = mrp_elem.find('span', {'class': 'a-offscreen'})
                    if offscreen:
                        prices['MRP (Original Price)'] = offscreen.text.strip()
            
            # Discount Percentage
            discount_elem = soup.find('span', {'class': 'savingsPercentage'})
            if discount_elem:
                prices['Discount'] = discount_elem.text.strip()
            else:
                # Calculate discount
                if 'Current Price' in prices and 'MRP (Original Price)' in prices:
                    try:
                        current = float(re.sub(r'[^\d.]', '', prices['Current Price']))
                        mrp = float(re.sub(r'[^\d.]', '', prices['MRP (Original Price)']))
                        discount = ((mrp - current) / mrp) * 100
                        prices['Discount'] = f"-{discount:.0f}%"
                        prices['You Save'] = f"₹{mrp - current:.2f}"
                    except:
                        pass
            
            # EMI Option
            emi_elem = soup.find('span', string=re.compile(r'EMI starts at', re.I))
            if emi_elem:
                prices['EMI Option'] = emi_elem.text.strip()
            
            # Availability
            avail_elem = soup.find('span', {'class': 'a-size-medium a-color-success'})
            if avail_elem:
                prices['Availability'] = avail_elem.text.strip()
            
        except Exception as e:
            print(f"⚠️  Error extracting prices: {e}")
        
        return prices if prices else {"Price": "Not available - Please check the URL"}
    
    def download_image(self, image_url, output_folder):
        """Download and save product image"""
        try:
            print(f"📥 Downloading product image...")
            response = requests.get(image_url, timeout=10)
            img = Image.open(BytesIO(response.content))
            
            image_path = os.path.join(output_folder, "product_image.jpg")
            img.save(image_path, 'JPEG', quality=95)
            
            return image_path
        except Exception as e:
            print(f"⚠️  Error downloading image: {e}")
            return None
    
    def save_info(self, title, url, prices, image_url, output_folder):
        """Save all information to text file"""
        try:
            info_path = os.path.join(output_folder, "product_info.txt")
            with open(info_path, 'w', encoding='utf-8') as f:
                f.write("=" * 80 + "\n")
                f.write("  AMAZON PRODUCT INFORMATION\n")
                f.write("=" * 80 + "\n\n")
                f.write(f"Product Title:\n{title}\n\n")
                f.write(f"Product URL:\n{url}\n\n")
                f.write("Prices:\n")
                for price_type, value in prices.items():
                    f.write(f"  {price_type}: {value}\n")
                f.write(f"\nProduct Image URL:\n{image_url}\n")
                f.write("\n" + "=" * 80 + "\n")
            
            print(f"\n✅ Info saved: {info_path}")
        except Exception as e:
            print(f"⚠️  Error saving info: {e}")
    
    def display_summary(self, title, prices, image_url, output_folder):
        """Display formatted summary"""
        print("\n" + "=" * 80)
        print("  📦 AMAZON PRODUCT SUMMARY")
        print("=" * 80)
        print(f"\n📝 Title:")
        print(f"   {title}")
        print(f"\n💰 Pricing:")
        for price_type, value in prices.items():
            print(f"   • {price_type}: {value}")
        if image_url:
            print(f"\n🖼️  Image URL:")
            print(f"   {image_url}")
        print(f"\n📁 Output Folder:")
        print(f"   {output_folder}/")
        print(f"\n📄 Files Saved:")
        print(f"   • product_image.jpg")
        print(f"   • product_info.txt")
        print("\n" + "=" * 80)


def main():
    import sys
    
    print("=" * 80)
    print("  🛒 Amazon Product Information Scraper")
    print("=" * 80)
    
    # Get URL from user
    if len(sys.argv) > 1:
        url = sys.argv[1]
    else:
        url = input("\n📝 Enter Amazon Product URL: ").strip()
    
    if not url:
        print("❌ No URL provided!")
        return
    
    # Validate URL
    if 'amazon' not in url.lower():
        print("❌ Please provide a valid Amazon product URL!")
        return
    
    scraper = AmazonProductScraper()
    result = scraper.scrape_product(url)
    
    if result:
        print("\n✅ Successfully scraped product information!")
    else:
        print("\n❌ Failed to scrape product information!")


if __name__ == "__main__":
    main()
