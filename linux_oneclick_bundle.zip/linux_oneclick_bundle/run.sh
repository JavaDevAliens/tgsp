#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$APP_DIR"

# shellcheck disable=SC1091
source .venv/bin/activate

export PYTHONUNBUFFERED=1

python monitor_channels.py
