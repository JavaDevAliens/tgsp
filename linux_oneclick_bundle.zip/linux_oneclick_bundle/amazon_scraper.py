"""
Amazon Product Information Scraper
Takes an Amazon product URL and extracts:
- Screenshot of the page
- Product title
- Product image
- All prices (current, original, discount)
"""

import os
import sys
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
import requests
from PIL import Image
from io import BytesIO
import re


class AmazonProductScraper:
    def __init__(self):
        """Initialize Chrome driver with options"""
        chrome_options = Options()
        chrome_options.add_argument('--headless=new')  # Run in background
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        chrome_options.add_argument('--window-size=1920,1080')
        chrome_options.add_argument('--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')
        
        print("🚀 Initializing Chrome driver...")
        self.driver = webdriver.Chrome(
            service=Service(ChromeDriverManager().install()),
            options=chrome_options
        )
        self.wait = WebDriverWait(self.driver, 10)
        
    def scrape_product(self, url):
        """Scrape Amazon product information"""
        try:
            print(f"\n📡 Loading product page: {url}")
            self.driver.get(url)
            
            # Wait for page to load
            self.wait.until(EC.presence_of_element_located((By.ID, "productTitle")))
            
            # Create output folder with timestamp
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            output_folder = f"amazon_product_{timestamp}"
            os.makedirs(output_folder, exist_ok=True)
            
            print(f"\n📁 Saving to folder: {output_folder}")
            
            # 1. Take screenshot
            screenshot_path = os.path.join(output_folder, "product_screenshot.png")
            self.driver.save_screenshot(screenshot_path)
            print(f"✅ Screenshot saved: {screenshot_path}")
            
            # 2. Get product title
            title = self.get_title()
            print(f"\n📝 Product Title:")
            print(f"   {title}")
            
            # Save title to file
            with open(os.path.join(output_folder, "product_info.txt"), 'w', encoding='utf-8') as f:
                f.write(f"Product Title:\n{title}\n\n")
                f.write(f"Product URL:\n{url}\n\n")
            
            # 3. Get product image
            image_url = self.get_main_image()
            if image_url:
                image_path = self.download_image(image_url, output_folder)
                print(f"✅ Product image saved: {image_path}")
            
            # 4. Get all prices
            prices = self.get_all_prices()
            print(f"\n💰 Prices:")
            
            price_info = []
            for price_type, price_value in prices.items():
                print(f"   {price_type}: {price_value}")
                price_info.append(f"{price_type}: {price_value}")
            
            # Save prices to file
            with open(os.path.join(output_folder, "product_info.txt"), 'a', encoding='utf-8') as f:
                f.write("Prices:\n")
                for price in price_info:
                    f.write(f"{price}\n")
            
            print(f"\n✅ All data saved to: {output_folder}")
            
            # Display summary
            self.display_summary(title, prices, output_folder)
            
            return {
                'title': title,
                'prices': prices,
                'image_url': image_url,
                'screenshot_path': screenshot_path,
                'output_folder': output_folder
            }
            
        except Exception as e:
            print(f"❌ Error scraping product: {e}")
            import traceback
            traceback.print_exc()
            return None
    
    def get_title(self):
        """Extract product title"""
        try:
            title_element = self.driver.find_element(By.ID, "productTitle")
            return title_element.text.strip()
        except:
            return "Title not found"
    
    def get_main_image(self):
        """Extract main product image URL"""
        try:
            # Try different selectors for product image
            selectors = [
                "//img[@id='landingImage']",
                "//div[@id='imgTagWrapperId']//img",
                "//div[@id='imageBlock']//img",
                "//img[contains(@class, 'a-dynamic-image')]"
            ]
            
            for selector in selectors:
                try:
                    img_element = self.driver.find_element(By.XPATH, selector)
                    img_url = img_element.get_attribute('src')
                    
                    # Get high-res version
                    if img_url and 'images-amazon' in img_url:
                        # Replace size parameters to get larger image
                        img_url = re.sub(r'\._.*?_\.', '._AC_SL1500_.', img_url)
                        return img_url
                except:
                    continue
            
            return None
        except:
            return None
    
    def get_all_prices(self):
        """Extract all price information"""
        prices = {}
        
        try:
            # Current Price (Deal Price)
            price_selectors = [
                "//span[@class='a-price-whole']",
                "//span[contains(@class, 'a-price')]//span[@class='a-offscreen']",
                "//span[@id='priceblock_ourprice']",
                "//span[@id='priceblock_dealprice']",
                "//span[contains(@class, 'apexPriceToPay')]//span[@class='a-offscreen']"
            ]
            
            for selector in price_selectors:
                try:
                    price_elem = self.driver.find_element(By.XPATH, selector)
                    price_text = price_elem.text if 'offscreen' not in selector else price_elem.get_attribute('textContent')
                    if price_text and '₹' in price_text:
                        prices['Current Price'] = price_text.strip()
                        break
                except:
                    continue
            
            # MRP / List Price (Original Price)
            mrp_selectors = [
                "//span[contains(@class, 'a-text-price')]//span[@class='a-offscreen']",
                "//span[@class='a-price a-text-price']//span[@aria-hidden='true']",
                "//span[contains(text(), 'M.R.P.:')]/..//span[@class='a-offscreen']"
            ]
            
            for selector in mrp_selectors:
                try:
                    mrp_elem = self.driver.find_element(By.XPATH, selector)
                    mrp_text = mrp_elem.text if 'offscreen' not in selector else mrp_elem.get_attribute('textContent')
                    if mrp_text and '₹' in mrp_text and mrp_text != prices.get('Current Price', ''):
                        prices['MRP (Original Price)'] = mrp_text.strip()
                        break
                except:
                    continue
            
            # Discount Percentage
            try:
                discount_elem = self.driver.find_element(By.XPATH, "//span[contains(@class, 'savingsPercentage')]")
                prices['Discount'] = discount_elem.text.strip()
            except:
                # Calculate discount if not shown
                if 'Current Price' in prices and 'MRP (Original Price)' in prices:
                    try:
                        current = float(re.sub(r'[^\d.]', '', prices['Current Price']))
                        mrp = float(re.sub(r'[^\d.]', '', prices['MRP (Original Price)']))
                        discount = ((mrp - current) / mrp) * 100
                        prices['Discount'] = f"-{discount:.0f}%"
                    except:
                        pass
            
            # You Save
            try:
                save_elem = self.driver.find_element(By.XPATH, "//span[contains(@class, 'a-color-price')]")
                save_text = save_elem.text.strip()
                if '₹' in save_text:
                    prices['You Save'] = save_text
            except:
                pass
            
            # EMI Options
            try:
                emi_elem = self.driver.find_element(By.XPATH, "//span[contains(text(), 'EMI starts at')]")
                prices['EMI Option'] = emi_elem.text.strip()
            except:
                pass
            
        except Exception as e:
            print(f"⚠️  Error extracting prices: {e}")
        
        return prices if prices else {"Price": "Not available"}
    
    def download_image(self, image_url, output_folder):
        """Download and save product image"""
        try:
            response = requests.get(image_url, timeout=10)
            img = Image.open(BytesIO(response.content))
            
            image_path = os.path.join(output_folder, "product_image.jpg")
            img.save(image_path, 'JPEG', quality=95)
            
            return image_path
        except Exception as e:
            print(f"⚠️  Error downloading image: {e}")
            return None
    
    def display_summary(self, title, prices, output_folder):
        """Display formatted summary"""
        print("\n" + "=" * 80)
        print("  📦 AMAZON PRODUCT SUMMARY")
        print("=" * 80)
        print(f"\n📝 Title: {title[:70]}...")
        print(f"\n💰 Pricing:")
        for price_type, value in prices.items():
            print(f"   • {price_type}: {value}")
        print(f"\n📁 Files saved in: {output_folder}/")
        print("   • product_screenshot.png")
        print("   • product_image.jpg")
        print("   • product_info.txt")
        print("\n" + "=" * 80)
    
    def close(self):
        """Close the browser"""
        self.driver.quit()


def main():
    print("=" * 80)
    print("  🛒 Amazon Product Information Scraper")
    print("=" * 80)
    
    # Get URL from user
    if len(sys.argv) > 1:
        url = sys.argv[1]
    else:
        url = input("\n📝 Enter Amazon Product URL: ").strip()
    
    if not url:
        print("❌ No URL provided!")
        return
    
    # Validate URL
    if 'amazon' not in url.lower():
        print("❌ Please provide a valid Amazon product URL!")
        return
    
    scraper = AmazonProductScraper()
    
    try:
        result = scraper.scrape_product(url)
        
        if result:
            print("\n✅ Successfully scraped product information!")
        else:
            print("\n❌ Failed to scrape product information!")
    
    finally:
        scraper.close()
        print("\n👋 Browser closed. Done!")


if __name__ == "__main__":
    main()
