#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$APP_DIR"

# shellcheck disable=SC1091
source .venv/bin/activate

export PYTHONUNBUFFERED=1

while true; do
  echo "[autoappnt] Starting monitor: $(date -Is)"
  python monitor_channels.py || true
  echo "[autoappnt] Monitor exited. Restarting in 5s..."
  sleep 5
done
