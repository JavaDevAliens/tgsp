#!/usr/bin/env bash

if [ -z "${BASH_VERSION:-}" ]; then
  if command -v bash >/dev/null 2>&1; then
    exec bash "$0" "$@"
  fi
  echo "ERROR: bash is required to run this script." >&2
  exit 1
fi

set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$APP_DIR"

# shellcheck disable=SC1091
source .venv/bin/activate

export PYTHONUNBUFFERED=1

while true; do
  echo "[autoappnt] Starting monitor: $(date -Is)"
  python monitor_channels.py || true
  echo "[autoappnt] Monitor exited. Restarting in 5s..."
  sleep 5
done
