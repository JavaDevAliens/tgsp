#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$APP_DIR"

echo "[autoappnt] Linux setup starting..."

# Ubuntu/Debian helper (optional): install system deps.
# Run with: AUTOAPPNT_APT=1 bash setup.sh
if [ "${AUTOAPPNT_APT:-0}" = "1" ]; then
  if command -v apt-get >/dev/null 2>&1; then
    echo "[autoappnt] Installing Ubuntu packages (requires sudo)..."
    sudo apt-get update
    sudo apt-get install -y python3 python3-venv python3-pip
  else
    echo "[autoappnt] AUTOAPPNT_APT=1 set but apt-get not found. Skipping."
  fi
fi

if ! command -v python3 >/dev/null 2>&1; then
  echo "ERROR: python3 is not installed. Install it first (e.g. apt install python3)." >&2
  exit 1
fi

# Ensure venv module exists (Debian/Ubuntu)
if ! python3 -c "import venv" >/dev/null 2>&1; then
  echo "[autoappnt] python3-venv missing. On Debian/Ubuntu run:" >&2
  echo "  sudo apt-get update && sudo apt-get install -y python3-venv" >&2
  exit 1
fi

if [ ! -d .venv ]; then
  echo "[autoappnt] Creating venv in $APP_DIR/.venv"
  python3 -m venv .venv
fi

# shellcheck disable=SC1091
source .venv/bin/activate

python -m pip install --upgrade pip wheel setuptools

REQ_FILE="requirements.txt"
if [ "${AUTOAPPNT_FULL:-0}" = "1" ]; then
  REQ_FILE="requirements_scraper.txt"
fi

echo "[autoappnt] Installing Python deps from $REQ_FILE"
python -m pip install --no-cache-dir -r "$REQ_FILE"

# Optional Playwright browser install (manual; can be heavy)
if [ "${AUTOAPPNT_INSTALL_PLAYWRIGHT_BROWSERS:-0}" = "1" ]; then
  if command -v playwright >/dev/null 2>&1; then
    echo "[autoappnt] Installing Playwright Chromium (may require sudo for system deps)."
    playwright install --with-deps chromium
  else
    echo "[autoappnt] 'playwright' command not found; did you install requirements_scraper.txt?" >&2
  fi
fi

mkdir -p "$HOME/.local/state/autoappnt/telethon_sessions"
mkdir -p "$HOME/.local/state/autoappnt"

if [ ! -f config.json ]; then
  echo "[autoappnt] Creating config.json from linux template."
  cp -f config.json.linux config.json
  echo "[autoappnt] Edit config.json now: api_id, api_hash, forward_target_channel_id." 
fi

echo "[autoappnt] Setup complete."
