#!/usr/bin/env bash

# Ensure bash (some mobile/proot environments run scripts under sh/ash).
if [ -z "${BASH_VERSION:-}" ]; then
  if command -v bash >/dev/null 2>&1; then
    exec bash "$0" "$@"
  fi
  echo "ERROR: bash is required to run this script." >&2
  exit 1
fi

set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$APP_DIR"

echo "[autoappnt] Linux setup starting..."

# Ubuntu/Debian helper (optional): install system deps.
# Run with: AUTOAPPNT_APT=1 bash setup.sh
if [ "${AUTOAPPNT_APT:-0}" = "1" ]; then
  if command -v apt-get >/dev/null 2>&1; then
    echo "[autoappnt] Installing Ubuntu packages (requires sudo)..."
    if command -v sudo >/dev/null 2>&1; then
      sudo apt-get update
      sudo apt-get install -y python3 python3-venv python3-pip
    else
      # Common in containers/proot where you're already root.
      apt-get update
      apt-get install -y python3 python3-venv python3-pip
    fi
  else
    echo "[autoappnt] AUTOAPPNT_APT=1 set but apt-get not found. Skipping."
  fi
fi

if ! command -v python3 >/dev/null 2>&1; then
  echo "ERROR: python3 is not installed. Install it first (e.g. apt install python3)." >&2
  exit 1
fi

# Ensure venv module exists (Debian/Ubuntu)
if ! python3 -c "import venv" >/dev/null 2>&1; then
  echo "[autoappnt] python3-venv missing. On Debian/Ubuntu run:" >&2
  echo "  sudo apt-get update && sudo apt-get install -y python3-venv" >&2
  exit 1
fi

if [ ! -d .venv ]; then
  echo "[autoappnt] Creating venv in $APP_DIR/.venv"
  python3 -m venv .venv
fi

# shellcheck disable=SC1091
source .venv/bin/activate

python -m pip install --upgrade pip wheel setuptools

echo "[autoappnt] Installing base Python deps (requirements.txt)"
python -m pip install --no-cache-dir -r "requirements.txt"

# Optional scraper deps (Playwright/Selenium helpers). Enable with:
#   AUTOAPPNT_SCRAPER=1 bash setup.sh
if [ "${AUTOAPPNT_SCRAPER:-0}" = "1" ]; then
  echo "[autoappnt] Installing scraper deps (requirements_scraper.txt)"
  python -m pip install --no-cache-dir -r "requirements_scraper.txt"
fi

# Optional Playwright browser install (manual; can be heavy)
# Typically used with AUTOAPPNT_SCRAPER=1.
if [ "${AUTOAPPNT_INSTALL_PLAYWRIGHT_BROWSERS:-0}" = "1" ]; then
  if command -v playwright >/dev/null 2>&1; then
    # Optional: install system dependencies via apt (best effort).
    # Enable with: AUTOAPPNT_INSTALL_PLAYWRIGHT_DEPS=1
    if [ "${AUTOAPPNT_INSTALL_PLAYWRIGHT_DEPS:-0}" = "1" ]; then
      if command -v apt-get >/dev/null 2>&1; then
        echo "[autoappnt] Installing Playwright system deps (best effort)"
        if command -v sudo >/dev/null 2>&1; then
          sudo playwright install-deps chromium || true
        else
          playwright install-deps chromium || true
        fi
      fi
    fi

    echo "[autoappnt] Installing Playwright Chromium."
    # On full Ubuntu with systemd/sudo, --with-deps is best.
    # On mobile/proot, --with-deps can fail; fall back to plain install.
    if ! playwright install --with-deps chromium; then
      echo "[autoappnt] playwright --with-deps failed; trying: playwright install chromium"
      playwright install chromium
    fi
  else
    echo "[autoappnt] 'playwright' command not found; did you install requirements_scraper.txt?" >&2
  fi
fi

mkdir -p "$HOME/.local/state/autoappnt/telethon_sessions"
mkdir -p "$HOME/.local/state/autoappnt"

if [ ! -f config.json ]; then
  echo "[autoappnt] Creating config.json from linux template."
  cp -f config.json.linux config.json
  echo "[autoappnt] Edit config.json now: api_id, api_hash, forward_target_channel_id." 
fi

echo "[autoappnt] Setup complete."
