# 🛒 Amazon Product Scraper - Complete Guide

## ✨ Features

This tool extracts complete product information from Amazon product URLs:

✅ **Product Title** - Full product name  
✅ **Product Image** - High-resolution product photo  
✅ **All Prices** - Current price, MRP, discount percentage, savings  
✅ **EMI Options** - Monthly payment plans  
✅ **Availability** - Stock status  

## 📝 How to Use

### Simple Method:
```powershell
python amazon_scraper_simple.py
```

When prompted, paste your Amazon product URL and press Enter.

### Command Line Method:
```powershell
python amazon_scraper_simple.py "YOUR_AMAZON_URL_HERE"
```

## 📦 Example

**Input URL:**
```
https://www.amazon.in/dp/B0DM6D8JFW
```

**Output:**
```
📦 AMAZON PRODUCT SUMMARY

📝 Title:
   Lifelong Stainless Steel Water Bottle 900ml | Durable, Leak-Proof...

💰 Pricing:
   • Current Price: ₹249.00
   • MRP (Original Price): ₹649.00
   • Discount: -62%
   • You Save: ₹400.00

📁 Output Folder: amazon_product_20251016_111404/
```

## 📂 Output Files

Creates a timestamped folder containing:
- `product_image.jpg` - Product image
- `product_info.txt` - Complete product details

## 💡 Tips

1. **Use complete product URLs** - Copy the full URL from your browser
2. **Check output folder** - All files are saved with timestamp
3. **Works best with** - Direct product pages (amazon.in/dp/...)

## 🎯 Ready to Use!

Just run the script and paste any Amazon India product URL!

```powershell
python amazon_scraper_simple.py
```

Then paste a URL like:
- https://www.amazon.in/dp/B0XXXXX
- https://www.amazon.in/product-name/dp/B0XXXXX

The tool will:
1. Extract all product information
2. Download the product image
3. Save everything to a new folder
4. Display a summary on screen

Enjoy! 🚀
