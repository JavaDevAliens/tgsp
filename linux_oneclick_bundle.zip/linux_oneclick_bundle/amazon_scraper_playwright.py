"""
Amazon Product Scraper with Screenshot (Playwright Version)
Extracts: Screenshot, Title, Image, All Prices
"""

import asyncio
import os
import re
from datetime import datetime
from playwright.async_api import async_playwright
import requests
from PIL import Image
from io import BytesIO


class AmazonScraperPlaywright:
    async def scrape_product(self, url):
        """Scrape Amazon product with screenshot"""
        async with async_playwright() as p:
            # Launch browser
            print("🚀 Launching browser...")
            browser = await p.chromium.launch(headless=True)
            
            # Create context with user agent
            context = await browser.new_context(
                user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                viewport={'width': 1920, 'height': 1080}
            )
            
            page = await context.new_page()
            
            try:
                # Create output folder
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                output_folder = f"amazon_product_{timestamp}"
                os.makedirs(output_folder, exist_ok=True)
                
                print(f"📡 Loading: {url}")
                
                # Navigate to page with longer timeout
                await page.goto(url, wait_until='domcontentloaded', timeout=60000)
                
                # Wait for product title to load
                await page.wait_for_selector('#productTitle', timeout=15000)
                
                print(f"📁 Saving to: {output_folder}\n")
                
                # 1. Take full page screenshot
                screenshot_path = os.path.join(output_folder, 'product_screenshot.png')
                await page.screenshot(path=screenshot_path, full_page=True)
                print(f"✅ Screenshot saved: {screenshot_path}")
                
                # 2. Get product title
                title = await self.get_title(page)
                print(f"\n📝 Product Title:")
                print(f"   {title}")
                
                # 3. Get product image
                image_url = await self.get_main_image(page)
                if image_url:
                    image_path = self.download_image(image_url, output_folder)
                    if image_path:
                        print(f"\n✅ Product image saved: {image_path}")
                
                # 4. Get all prices
                prices = await self.get_all_prices(page)
                print(f"\n💰 Prices:")
                for price_type, price_value in prices.items():
                    print(f"   • {price_type}: {price_value}")
                
                # Save info to file
                self.save_info(title, url, prices, image_url, output_folder)
                
                # Display summary
                self.display_summary(title, prices, image_url, output_folder)
                
                await browser.close()
                
                return {
                    'title': title,
                    'prices': prices,
                    'image_url': image_url,
                    'screenshot_path': screenshot_path,
                    'output_folder': output_folder
                }
                
            except Exception as e:
                print(f"❌ Error: {e}")
                await browser.close()
                return None
    
    async def get_title(self, page):
        """Extract product title"""
        try:
            title_elem = await page.query_selector('#productTitle')
            if title_elem:
                title = await title_elem.inner_text()
                return title.strip()
            return "Title not found"
        except:
            return "Title not found"
    
    async def get_main_image(self, page):
        """Extract main product image URL"""
        try:
            # Try main image
            img_elem = await page.query_selector('#landingImage')
            if img_elem:
                img_url = await img_elem.get_attribute('src')
                if img_url:
                    # Get high-res version
                    img_url = re.sub(r'\._.*?_\.', '._AC_SL1500_.', img_url)
                    return img_url
            
            # Alternative selector
            img_elem = await page.query_selector('.a-dynamic-image')
            if img_elem:
                img_url = await img_elem.get_attribute('src')
                return img_url
            
            return None
        except:
            return None
    
    async def get_all_prices(self, page):
        """Extract all price information"""
        prices = {}
        
        try:
            # Current Price
            price_whole = await page.query_selector('.a-price-whole')
            if price_whole:
                whole = await price_whole.inner_text()
                price_fraction = await page.query_selector('.a-price-fraction')
                fraction = await price_fraction.inner_text() if price_fraction else '00'
                prices['Current Price'] = f"₹{whole.strip()}{fraction.strip()}"
            
            # MRP / Original Price
            mrp_elem = await page.query_selector('.a-price.a-text-price .a-offscreen')
            if mrp_elem:
                mrp_text = await mrp_elem.inner_text()
                prices['MRP (Original Price)'] = mrp_text.strip()
            
            # Discount Percentage
            discount_elem = await page.query_selector('.savingsPercentage')
            if discount_elem:
                discount_text = await discount_elem.inner_text()
                prices['Discount'] = discount_text.strip()
            elif 'Current Price' in prices and 'MRP (Original Price)' in prices:
                # Calculate discount
                try:
                    current = float(re.sub(r'[^\d.]', '', prices['Current Price']))
                    mrp = float(re.sub(r'[^\d.]', '', prices['MRP (Original Price)']))
                    discount = ((mrp - current) / mrp) * 100
                    saving = mrp - current
                    prices['Discount'] = f"-{discount:.0f}%"
                    prices['You Save'] = f"₹{saving:.2f}"
                except:
                    pass
            
            # Deal badge
            deal_badge = await page.query_selector('#dealBadge')
            if deal_badge:
                deal_text = await deal_badge.inner_text()
                prices['Deal Type'] = deal_text.strip()
            
            # Availability
            avail_elem = await page.query_selector('#availability span')
            if avail_elem:
                avail_text = await avail_elem.inner_text()
                prices['Availability'] = avail_text.strip()
            
        except Exception as e:
            print(f"⚠️  Error extracting prices: {e}")
        
        return prices if prices else {"Price": "Not available"}
    
    def download_image(self, image_url, output_folder):
        """Download and save product image"""
        try:
            print(f"📥 Downloading product image...")
            response = requests.get(image_url, timeout=10)
            img = Image.open(BytesIO(response.content))
            
            image_path = os.path.join(output_folder, "product_image.jpg")
            img.save(image_path, 'JPEG', quality=95)
            
            return image_path
        except Exception as e:
            print(f"⚠️  Error downloading image: {e}")
            return None
    
    def save_info(self, title, url, prices, image_url, output_folder):
        """Save all information to text file"""
        try:
            info_path = os.path.join(output_folder, "product_info.txt")
            with open(info_path, 'w', encoding='utf-8') as f:
                f.write("=" * 80 + "\n")
                f.write("  AMAZON PRODUCT INFORMATION\n")
                f.write("=" * 80 + "\n\n")
                f.write(f"Product Title:\n{title}\n\n")
                f.write(f"Product URL:\n{url}\n\n")
                f.write("Prices:\n")
                for price_type, value in prices.items():
                    f.write(f"  {price_type}: {value}\n")
                if image_url:
                    f.write(f"\nProduct Image URL:\n{image_url}\n")
                f.write("\n" + "=" * 80 + "\n")
            
            print(f"\n✅ Info saved: {info_path}")
        except Exception as e:
            print(f"⚠️  Error saving info: {e}")
    
    def display_summary(self, title, prices, image_url, output_folder):
        """Display formatted summary"""
        print("\n" + "=" * 80)
        print("  📦 AMAZON PRODUCT SUMMARY")
        print("=" * 80)
        print(f"\n📝 Title:")
        print(f"   {title}")
        print(f"\n💰 Pricing:")
        for price_type, value in prices.items():
            print(f"   • {price_type}: {value}")
        if image_url:
            print(f"\n🖼️  Image URL:")
            print(f"   {image_url}")
        print(f"\n📁 Output Folder:")
        print(f"   {output_folder}/")
        print(f"\n📄 Files Saved:")
        print(f"   • product_screenshot.png (Full page screenshot)")
        print(f"   • product_image.jpg (Product image)")
        print(f"   • product_info.txt (All details)")
        print("\n" + "=" * 80)


async def main():
    import sys
    
    print("=" * 80)
    print("  🛒 Amazon Product Scraper (With Screenshot)")
    print("=" * 80)
    
    # Get URL from user
    if len(sys.argv) > 1:
        url = sys.argv[1]
    else:
        url = input("\n📝 Enter Amazon Product URL: ").strip()
    
    if not url:
        print("❌ No URL provided!")
        return
    
    # Validate URL
    if 'amazon' not in url.lower():
        print("❌ Please provide a valid Amazon product URL!")
        return
    
    scraper = AmazonScraperPlaywright()
    result = await scraper.scrape_product(url)
    
    if result:
        print("\n✅ Successfully scraped product information!")
    else:
        print("\n❌ Failed to scrape product information!")


if __name__ == "__main__":
    asyncio.run(main())
