"""
Monitor Multiple Telegram Channels - Real-time Notification Reader
This script monitors specified channels and prints new messages to console.
"""

import asyncio
import logging
from datetime import datetime
from telethon import TelegramClient, events
from telethon.tl.types import InputPeerChannel
import json
import sys
import re
import os
import signal
from io import BytesIO
import html
from pathlib import Path
from urllib.parse import urlparse
import urllib.request
import urllib.error
import sqlite3
from typing import Any

from contextlib import suppress

import requests


def _is_termux() -> bool:
    # Termux typically sets TERMUX_VERSION. PREFIX usually contains /data/data/com.termux.
    if os.environ.get('TERMUX_VERSION'):
        return True
    prefix = os.environ.get('PREFIX') or ''
    if 'com.termux' in prefix:
        return True
    try:
        return Path('/data/data/com.termux/files/usr').exists()
    except Exception:
        return False


IS_TERMUX = _is_termux()

try:
    from playwright.async_api import async_playwright  # type: ignore
except Exception:  # pragma: no cover
    async_playwright = None

try:
    from bs4 import BeautifulSoup  # type: ignore
except Exception:  # pragma: no cover
    BeautifulSoup = None

# Set UTF-8 encoding for Windows console
if sys.platform == 'win32':
    sys.stdout.reconfigure(encoding='utf-8')
    sys.stderr.reconfigure(encoding='utf-8')

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('channel_monitor.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Load configuration
with open('config.json', 'r', encoding='utf-8') as f:
    config = json.load(f)

api_id = config['api_id']
api_hash = config['api_hash']

# --- Session handling (avoid OneDrive SQLite locks) ---
# Telethon sessions are SQLite files; keeping them under OneDrive can cause "database is locked".
SESSION_BASE_NAME = config.get('monitor_session_name') or config.get('session_name') or 'channel_monitor_session'

_configured_session_dir = config.get('session_dir')
if _configured_session_dir:
    SESSION_DIR = Path(_configured_session_dir).expanduser()
else:
    if sys.platform == 'win32':
        _default_localappdata = os.environ.get('LOCALAPPDATA')
        _fallback_local = str(Path.home() / 'AppData' / 'Local')
        _base = Path(_default_localappdata or _fallback_local)
        SESSION_DIR = _base / 'autoappnt' / 'telethon_sessions'
    else:
        _base = Path(os.environ.get('XDG_STATE_HOME') or os.environ.get('XDG_DATA_HOME') or (Path.home() / '.local' / 'state'))
        SESSION_DIR = _base / 'autoappnt' / 'telethon_sessions'

SESSION_DIR.mkdir(parents=True, exist_ok=True)


def _session_path(base_name: str) -> str:
    return str(SESSION_DIR / base_name)


def _is_db_locked_error(err: BaseException) -> bool:
    return isinstance(err, sqlite3.OperationalError) and 'database is locked' in str(err).lower()


def _acquire_single_instance_lock() -> Any:
    """Acquire a cross-process lock so you can't run two monitors at once."""
    candidates: list[Path] = [SESSION_DIR / 'monitor.lock']
    temp_dir = os.environ.get('TEMP') or os.environ.get('TMP')
    if temp_dir:
        candidates.append(Path(temp_dir) / 'autoappnt_monitor.lock')

    last_err: BaseException | None = None
    for lock_path in candidates:
        try:
            lock_path.parent.mkdir(parents=True, exist_ok=True)
            fp = open(lock_path, 'a+', encoding='utf-8')
        except Exception as e:
            last_err = e
            continue

        try:
            # On Windows, msvcrt.locking() locks from the current file position.
            # Ensure every process locks the same byte range (byte 0).
            fp.seek(0, os.SEEK_END)
            if fp.tell() == 0:
                fp.write('0')
                fp.flush()
            fp.seek(0)

            if sys.platform == 'win32':
                import msvcrt

                msvcrt.locking(fp.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl

                fcntl.flock(fp.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)

            fp.seek(0)
            fp.truncate()
            fp.write(str(os.getpid()))
            fp.flush()
            return fp
        except OSError as e:
            # Windows commonly raises EACCES when the region is already locked.
            with suppress(Exception):
                fp.close()
            if getattr(e, 'errno', None) == 13:
                raise RuntimeError('Another monitor instance is already running.')
            raise RuntimeError('Another monitor instance is already running.')
        except Exception as e:
            with suppress(Exception):
                fp.close()
            last_err = e
            continue

    if last_err is not None:
        # Surface the specific path that failed, if available.
        if isinstance(last_err, PermissionError):
            raise RuntimeError(f"Permission denied while creating lock file: {getattr(last_err, 'filename', '')}")
        raise RuntimeError(f"Failed to create instance lock: {last_err}")

    raise RuntimeError('Failed to create instance lock.')


def _release_single_instance_lock(fp: Any) -> None:
    if not fp:
        return
    try:
        if sys.platform == 'win32':
            import msvcrt

            with suppress(OSError):
                fp.seek(0)
                msvcrt.locking(fp.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl

            with suppress(OSError):
                fcntl.flock(fp.fileno(), fcntl.LOCK_UN)
    finally:
        with suppress(Exception):
            fp.close()


# --- Channels source (prefer refreshed JSON if present) ---
CHANNELS_FILE = config.get('channels_to_monitor_file') or 'channels_to_monitor.json'

# --- Soft stop ---
# Create this file to request a graceful stop of the monitor.
STOP_FILE = Path(config.get('monitor_stop_file') or 'monitor.stop').expanduser()
STOP_POLL_SECONDS = float(config.get('monitor_stop_poll_seconds', 2.0))


def _load_channels_from_file(path: str) -> list[object] | None:
    try:
        file_path = Path(path)
        if not file_path.exists():
            return None
        data = json.loads(file_path.read_text(encoding='utf-8'))
        if isinstance(data, dict) and isinstance(data.get('channels'), list):
            specs: list[object] = []
            for item in data['channels']:
                if isinstance(item, dict) and 'chat' in item:
                    specs.append(item['chat'])
            return specs or None
        if isinstance(data, list):
            return data
    except Exception:
        return None
    return None


def _chat_spec_to_input(chat_spec: object) -> object:
    # int id, str username, or {id, access_hash}
    if isinstance(chat_spec, (int, str)):
        return chat_spec
    if isinstance(chat_spec, dict) and 'id' in chat_spec and 'access_hash' in chat_spec:
        try:
            return InputPeerChannel(int(chat_spec['id']), int(chat_spec['access_hash']))
        except Exception:
            return chat_spec
    return chat_spec


def _get_channels_to_monitor() -> list[object]:
    from_file = _load_channels_from_file(CHANNELS_FILE)
    if from_file:
        return from_file
    from_config = config.get('channels_to_monitor')
    if isinstance(from_config, list) and from_config:
        return from_config
    return CHANNELS_TO_MONITOR


# --- Forwarding (monitor -> your channel) ---
FORWARD_ENABLED_DEFAULT = bool(config.get('forward_to_channel', False))
FORWARD_TARGET_DEFAULT = config.get('forward_target_channel_id') or config.get('target_channel_id')
FORWARD_MODE_DEFAULT = (config.get('forward_mode') or 'copy').lower()  # 'copy' or 'forward'
FORWARD_ORIGINAL_MESSAGE_DEFAULT = bool(config.get('forward_original_message', False))
INCLUDE_ORIGINAL_MESSAGE_MEDIA_DEFAULT = bool(config.get('include_original_message_media', False))

SCRAPE_AND_SEND_DEFAULT = bool(config.get('scrape_and_send', False))
SCRAPE_SEND_IMAGE_DEFAULT = bool(config.get('scrape_send_image', True))
SCRAPE_IMAGE_MAX_BYTES = int(config.get('scrape_image_max_bytes', 8 * 1024 * 1024))
MESSAGE_IMAGE_MAX_BYTES = int(config.get('message_image_max_bytes', 20 * 1024 * 1024))
SCRAPE_TIMEOUT_SECONDS = float(config.get('scrape_timeout_seconds', 12))

# Scrape engine: 'requests' (lightweight) or 'playwright' (full screenshot + exact product image)
# If not configured, prefer Playwright when installed so "entire screen" screenshots work out of the box.
SCRAPE_ENGINE_DEFAULT = (
    config.get('scrape_engine')
    or ('playwright' if (async_playwright is not None and not IS_TERMUX) else 'requests')
).strip().lower()
SCRAPE_INCLUDE_SCREENSHOT_DEFAULT = bool(config.get('scrape_include_screenshot', True)) and (not IS_TERMUX)
SCRAPE_SCREENSHOT_MAX_BYTES = int(config.get('scrape_screenshot_max_bytes', 10 * 1024 * 1024))


def _is_amazon_url(url: str) -> bool:
    if not url or not isinstance(url, str):
        return False
    try:
        parsed = urlparse(url)
        host = (parsed.netloc or '').lower()
        if not host:
            return False
        if host.startswith('www.'):
            host = host[4:]

        # Shorteners / canonical Amazon hosts
        if host in {'amzn.to', 'amzn.in'}:
            return True

        # Typical Amazon storefront domains
        amazon_hosts = {
            'amazon.in',
            'amazon.com',
            'amazon.ae',
            'amazon.sa',
            'amazon.co.uk',
            'amazon.de',
            'amazon.fr',
            'amazon.it',
            'amazon.es',
            'amazon.ca',
            'amazon.com.au',
            'amazon.sg',
            'amazon.jp',
        }
        return host in amazon_hosts or any(host.endswith('.' + h) for h in amazon_hosts)
    except Exception:
        return False


def _message_has_amazon_url(message) -> bool:
    # Check raw text for URLs.
    text = getattr(message, 'message', None) or ''
    if text:
        for url in re.findall(r'https?://\S+', text):
            # Strip common trailing punctuation
            url = url.rstrip(').,]"\'')
            if _is_amazon_url(url):
                return True

    # Check text-url entities (explicit link target)
    entities = getattr(message, 'entities', None) or []
    for ent in entities:
        url = getattr(ent, 'url', None)
        if url and _is_amazon_url(url):
            return True

    # Check URL buttons (if present)
    buttons = getattr(message, 'buttons', None)
    if buttons:
        try:
            for row in buttons:
                for btn in row:
                    btn_url = getattr(btn, 'url', None)
                    if btn_url and _is_amazon_url(btn_url):
                        return True
        except Exception:
            pass

    return False


def _extract_candidate_urls_from_message(message) -> list[str]:
    urls: list[str] = []

    text = getattr(message, 'message', None) or ''
    if text:
        for url in re.findall(r'https?://\S+', text):
            urls.append(url.rstrip(').,]"\''))

    entities = getattr(message, 'entities', None) or []
    for ent in entities:
        url = getattr(ent, 'url', None)
        if url:
            urls.append(str(url))

    buttons = getattr(message, 'buttons', None)
    if buttons:
        try:
            for row in buttons:
                for btn in row:
                    btn_url = getattr(btn, 'url', None)
                    if btn_url:
                        urls.append(str(btn_url))
        except Exception:
            pass

    # Keep order, de-duplicate
    seen: set[str] = set()
    out: list[str] = []
    for u in urls:
        if u and u not in seen:
            seen.add(u)
            out.append(u)
    return out


def _replace_amazon_tag(url: str) -> str:
    if not url:
        return url
    try:
        # Remove existing tag parameter
        url = re.sub(r'[?&]tag=[^&]*', '', url)
        separator = '&' if '?' in url else '?'
        return f"{url}{separator}tag=localseller0b-21"
    except Exception:
        return url


def _parse_inr_amount(value: str) -> float | None:
    if not value:
        return None
    try:
        cleaned = re.sub(r'[^\d.,]', '', value)
        cleaned = cleaned.replace(',', '')
        if not cleaned:
            return None
        return float(cleaned)
    except Exception:
        return None


def _format_inr(amount: float | None) -> str | None:
    if amount is None:
        return None
    try:
        if abs(amount - round(amount)) < 1e-9:
            return f"₹{int(round(amount)):,}"
        return f"₹{amount:,.2f}"
    except Exception:
        return None


def _format_inr_caption_style(value: str) -> str | None:
    """Format price as '₹ 1,234/-' for captions."""
    if not value:
        return None
    amt = _parse_inr_amount(value)
    if amt is None:
        # best-effort: keep whatever was provided
        v = value.strip()
        if not v:
            return None
        # ensure rupee sign and spacing
        if not v.startswith('₹'):
            v = '₹ ' + v
        if '/-' not in v:
            v = v.rstrip() + '/-'
        return v

    # Caption style generally uses integer rupees.
    return f"₹ {int(round(amt)):,}/-"


def _extract_price_discount_from_text(text: str) -> dict[str, str]:
    """Best-effort extraction of MRP / deal price / discount / saved from message text."""
    if not text:
        return {}

    out: dict[str, str] = {}

    # MRP: look for "MRP" / "M.R.P" near an INR amount.
    m_mrp = re.search(r'\bM\.?R\.?P\.?\b[^\n\r₹]*?(₹\s*[\d,]+(?:\.\d{1,2})?)', text, flags=re.IGNORECASE)
    if m_mrp:
        out['mrp'] = re.sub(r'\s+', ' ', m_mrp.group(1)).strip()
    else:
        m_mrp2 = re.search(r'\bM\.?R\.?P\.?\b[^\n\r]*?\b(?:rs\.?|inr)\s*([\d,]+(?:\.\d{1,2})?)\b', text, flags=re.IGNORECASE)
        if m_mrp2:
            out['mrp'] = f"₹{m_mrp2.group(1)}"

    # Price after discount: prioritize amounts near keywords, else first INR.
    m_deal = re.search(r'\b(?:deal|price|now|at|only)\b[^\n\r₹]*?(₹\s*[\d,]+(?:\.\d{1,2})?)', text, flags=re.IGNORECASE)
    if not m_deal:
        m_deal = re.search(r'(₹\s*[\d,]+(?:\.\d{1,2})?)', text)
    if m_deal:
        out['price'] = re.sub(r'\s+', ' ', m_deal.group(1)).strip()
    else:
        m_price2 = re.search(r'\b(?:rs\.?|inr)\s*([\d,]+(?:\.\d{1,2})?)\b', text, flags=re.IGNORECASE)
        if m_price2:
            out['price'] = f"₹{m_price2.group(1)}"

    # Discount: formats: 60% off | 60%OFF | 60% discount | -60%
    m_disc = re.search(r'\b(-?\d{1,2})\s*%\s*(?:off|discount)\b', text, flags=re.IGNORECASE)
    if not m_disc:
        m_disc = re.search(r'\b(-?\d{1,2})\s*%\s*\b', text, flags=re.IGNORECASE)
    if m_disc:
        val = m_disc.group(1)
        if not val.startswith('-'):
            val = '-' + val
        out['discount'] = f"{val}%"

    mrp_val = _parse_inr_amount(out.get('mrp', ''))
    price_val = _parse_inr_amount(out.get('price', ''))
    if mrp_val is not None and price_val is not None and mrp_val >= price_val:
        fmt = _format_inr(mrp_val - price_val)
        if fmt:
            out['saved'] = fmt

    return out


def _expand_url_requests(url: str, timeout_seconds: float) -> str:
    # Best-effort: follow redirects using HEAD then GET if needed.
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36',
        'Accept-Language': 'en-US,en;q=0.9',
    }
    try:
        r = requests.head(url, allow_redirects=True, timeout=timeout_seconds, headers=headers)
        if getattr(r, 'url', None):
            return str(r.url)
    except Exception:
        pass
    try:
        r = requests.get(url, allow_redirects=True, timeout=timeout_seconds, headers=headers)
        if getattr(r, 'url', None):
            return str(r.url)
    except Exception:
        pass
    return url


def _first_amazon_url_for_message(message) -> str | None:
    for raw in _extract_candidate_urls_from_message(message):
        expanded = _expand_url_requests(raw, SCRAPE_TIMEOUT_SECONDS) if raw else raw
        if _is_amazon_url(expanded):
            return _replace_amazon_tag(expanded)
        if _is_amazon_url(raw):
            return _replace_amazon_tag(raw)
    return None


def _scrape_amazon_product(url: str, timeout_seconds: float) -> dict[str, str]:
    """Best-effort Amazon product scrape. Returns small dict; empty dict on failure."""
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36',
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    }
    try:
        resp = requests.get(url, headers=headers, timeout=timeout_seconds)
        html = resp.text or ''
    except Exception:
        return {}

    if not html:
        return {}

    title = ''
    price = ''
    rating = ''
    image_url = ''
    mrp = ''

    if BeautifulSoup is not None:
        soup = BeautifulSoup(html, 'html.parser')

        og_title = soup.find('meta', attrs={'property': 'og:title'})
        if og_title and og_title.get('content'):
            title = str(og_title.get('content')).strip()

        if not title:
            pt = soup.select_one('#productTitle')
            if pt and pt.get_text():
                title = pt.get_text(strip=True)

        if not title and soup.title and soup.title.get_text():
            title = soup.title.get_text(strip=True)

        price_meta = soup.find('meta', attrs={'property': 'product:price:amount'})
        if price_meta and price_meta.get('content'):
            price = str(price_meta.get('content')).strip()

        if not price:
            p = soup.select_one('span.a-price span.a-offscreen')
            if p and p.get_text():
                price = p.get_text(strip=True)

        mrp_meta = soup.find('meta', attrs={'property': 'product:price:list'})
        if mrp_meta and mrp_meta.get('content'):
            mrp = str(mrp_meta.get('content')).strip()

        if not mrp:
            mrp_elem = soup.select_one('span.a-text-price span.a-offscreen')
            if mrp_elem and mrp_elem.get_text():
                mrp = mrp_elem.get_text(strip=True)

        r = soup.select_one('#acrPopover')
        if r and r.get('title'):
            rating = str(r.get('title')).strip()
        if not rating:
            r2 = soup.select_one('i.a-icon-star span.a-icon-alt')
            if r2 and r2.get_text():
                rating = r2.get_text(strip=True)

        og_image = soup.find('meta', attrs={'property': 'og:image'})
        if og_image and og_image.get('content'):
            image_url = str(og_image.get('content')).strip()

        if not image_url:
            tw_image = soup.find('meta', attrs={'name': 'twitter:image'})
            if tw_image and tw_image.get('content'):
                image_url = str(tw_image.get('content')).strip()

        if not image_url:
            img = soup.select_one('#landingImage')
            if img and img.get('src'):
                image_url = str(img.get('src')).strip()

        if not image_url:
            img2 = soup.find('img', attrs={'data-old-hires': True})
            if img2 and img2.get('data-old-hires'):
                image_url = str(img2.get('data-old-hires')).strip()
    else:
        m = re.search(r'<title>(.*?)</title>', html, re.IGNORECASE | re.DOTALL)
        if m:
            title = re.sub(r'\s+', ' ', m.group(1)).strip()

        m_img = re.search(r'property=["\']og:image["\']\s+content=["\'](.*?)["\']', html, re.IGNORECASE)
        if m_img:
            image_url = m_img.group(1).strip()

    out: dict[str, str] = {}
    if title:
        out['title'] = title
    if price:
        out['price'] = price
    if mrp:
        out['mrp'] = mrp
    if rating:
        out['rating'] = rating
    if image_url:
        out['image_url'] = image_url
    return out


async def _scrape_amazon_product_playwright(url: str, timeout_seconds: float, want_screenshot: bool) -> dict[str, object]:
    """Heavier scrape that can return product image bytes + full-page screenshot bytes."""
    if IS_TERMUX:
        raise RuntimeError('Playwright is not supported on Termux/Android; use scrape_engine="requests"')
    if async_playwright is None:
        raise RuntimeError("Playwright is not installed")

    nav_timeout_ms = int(max(5.0, timeout_seconds) * 1000)

    async with async_playwright() as p:  # type: ignore[operator]
        browser = await p.chromium.launch(headless=True)
        context = await browser.new_context(
            user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36',
            viewport={'width': 1280, 'height': 720},
        )
        page = await context.new_page()
        try:
            await page.goto(url, wait_until='domcontentloaded', timeout=nav_timeout_ms)

            # Some Amazon flows show an interstitial with a "Continue shopping" button.
            # Click it before we try to read title/price or take screenshots.
            clicked_continue = False
            for sel in (
                "button:has-text('Continue shopping')",
                "button:has-text('Continue Shopping')",
                "a:has-text('Continue shopping')",
                "a:has-text('Continue Shopping')",
                "input[type=submit][value*='Continue']",
            ):
                with suppress(Exception):
                    loc = page.locator(sel).first
                    if await loc.count() > 0:
                        await loc.click(timeout=min(4000, nav_timeout_ms))
                        clicked_continue = True
                        break

            if clicked_continue:
                with suppress(Exception):
                    await page.wait_for_load_state('domcontentloaded', timeout=min(15000, nav_timeout_ms))
                with suppress(Exception):
                    await page.wait_for_load_state('networkidle', timeout=min(15000, nav_timeout_ms))

            # Product pages can lazy-load; wait a bit for key elements.
            with suppress(Exception):
                await page.wait_for_selector('#productTitle', timeout=min(15000, nav_timeout_ms))

            # Reduce noise for screenshots: hide common header/footer/nav elements.
            # (We still fall back if selectors change.)
            if want_screenshot:
                with suppress(Exception):
                    await page.add_style_tag(content="""
/* Amazon header/nav */
#navbar, #nav-main, #nav-belt, #nav-tools, #nav-upnav, #nav-subnav,
#nav-swmslot, #navSwmHoliday, #nav-progressive-subnav,
#nav-global-location-slot, #nav-logo, #nav-search, #nav-cart,
/* App banners / popups */
#nav-main .nav-left, #nav-main .nav-right, #nav-main .nav-fill,
#a-page .a-popover, .a-modal-scroller, .a-modal-overlay,
/* Footer */
#navFooter, #navFooterNav, #navFooterCopyright, footer,
/* Recommendations / extra below-the-fold */
#rhf, #desktop-rhf, #sims-fbt, #sims-fbt-container, #sp_detail, #sp_detail2,
#sponsoredProducts2_feature_div, #sponsoredProducts_feature_div,
#dp-advertising, #dp-ads, .navFooterBackToTop {
  display: none !important;
  visibility: hidden !important;
}
body { background: #fff !important; }
""")

            # Title
            title = ''
            with suppress(Exception):
                el = await page.query_selector('#productTitle')
                if el:
                    title = (await el.inner_text()).strip()

            # Deal/current price
            deal_price = ''

            # Preferred path: visible on-screen price.
            # Example HTML:
            #   <span aria-hidden="true"><span class="a-price-symbol">₹</span><span class="a-price-whole">179</span></span>
            for root_sel in (
                '#corePriceDisplay_desktop_feature_div',
                '#apex_desktop',
                '#apex_offerDisplay_desktop',
                '#ppd',
                '#dp',
            ):
                if deal_price:
                    break
                with suppress(Exception):
                    parent = page.locator(
                        f"{root_sel} span[aria-hidden='true']:has(span.a-price-symbol):has(span.a-price-whole)"
                    ).first
                    if await parent.count() > 0:
                        symbol = (await parent.locator('span.a-price-symbol').first.inner_text()).strip()
                        whole = (await parent.locator('span.a-price-whole').first.inner_text()).strip()
                        frac = ''
                        with suppress(Exception):
                            frac_loc = parent.locator('span.a-price-fraction').first
                            if await frac_loc.count() > 0:
                                frac = (await frac_loc.inner_text()).strip()

                        whole = re.sub(r'[^\d,]', '', whole)
                        frac = re.sub(r'[^\d]', '', frac)
                        if symbol and whole:
                            deal_price = f"{symbol}{whole}" + (f".{frac}" if frac else '')

            for sel in (
                '#corePriceDisplay_desktop_feature_div .a-price .a-offscreen',
                'span.a-price span.a-offscreen',
                '#priceblock_dealprice',
                '#priceblock_ourprice',
            ):
                if deal_price:
                    break
                with suppress(Exception):
                    el = await page.query_selector(sel)
                    if el:
                        txt = (await el.inner_text()).strip()
                        if txt:
                            deal_price = txt
                            break

            # Regular / MRP
            regular_price = ''

            # Preferred path: explicit on-screen M.R.P. block (basisPrice).
            # Example HTML:
            #   <span class="basisPrice">M.R.P.: <span class="a-offscreen">₹459</span> ...</span>
            with suppress(Exception):
                mrp_loc = (
                    page.locator("span.basisPrice:has-text('M.R.P')").locator('span.a-offscreen').first
                )
                if await mrp_loc.count() > 0:
                    txt = (await mrp_loc.inner_text()).strip()
                    if txt:
                        regular_price = txt

            for sel in (
                'span.basisPrice span.a-offscreen',
                'span.basisPrice span.a-price span.a-offscreen',
                '#corePriceDisplay_desktop_feature_div span.a-text-price span.a-offscreen',
                '#apex_desktop span.a-text-price span.a-offscreen',
                '#apex_offerDisplay_desktop span.a-text-price span.a-offscreen',
                'span.a-text-price span.a-offscreen',
            ):
                if regular_price:
                    break
                with suppress(Exception):
                    el = await page.query_selector(sel)
                    if el:
                        txt = (await el.inner_text()).strip()
                        if txt:
                            regular_price = txt
                            break

            # If the list-price selectors fail, explicitly read the on-screen M.R.P. label/value.
            if not regular_price:
                with suppress(Exception):
                    mrp_from_screen = await page.evaluate(
                        r"""
() => {
  const labelRe = /\bM\.?R\.?P\.?\b/i;
  const captureRe = /\bM\.?R\.?P\.?\b[^₹\n\r]*?(₹\s*[\d,.]+)/i;

  // Try targeted, common price blocks first.
  const roots = [
    document.querySelector('#corePriceDisplay_desktop_feature_div'),
    document.querySelector('#apex_desktop'),
    document.querySelector('#apex_offerDisplay_desktop'),
    document.querySelector('#dp'),
    document.body,
  ].filter(Boolean);

  for (const root of roots) {
    const text = (root.innerText || '').replace(/\s+/g, ' ');
    const m = text.match(captureRe);
    if (m && m[1]) return m[1].trim();
  }

  // Fallback: scan elements that mention MRP and attempt to capture a nearby ₹ amount.
  const nodes = Array.from(document.querySelectorAll('body *'));
  for (const el of nodes) {
    const t = (el.textContent || '');
    if (!labelRe.test(t)) continue;
    const scope = (el.closest('tr') || el.closest('div') || el.parentElement || el);
    const scopeText = ((scope && (scope.innerText || scope.textContent)) || '').replace(/\s+/g, ' ');
    const m = scopeText.match(captureRe);
    if (m && m[1]) return m[1].trim();
  }

  return '';
}
"""
                    )
                    if isinstance(mrp_from_screen, str) and mrp_from_screen.strip():
                        regular_price = mrp_from_screen.strip()

            # Product image URL (exact)
            image_url = ''
            for sel in ('#landingImage', 'img.a-dynamic-image'):
                with suppress(Exception):
                    el = await page.query_selector(sel)
                    if el:
                        # Prefer hi-res attributes when present
                        u = await el.get_attribute('data-old-hires')
                        if not u:
                            u = await el.get_attribute('src')
                        if u:
                            image_url = str(u).strip()
                            break

            product_image_bytes: bytes | None = None
            if image_url:
                try:
                    product_image_bytes = await asyncio.to_thread(
                        _download_image_bytes,
                        image_url,
                        min(timeout_seconds, 15.0),
                        SCRAPE_IMAGE_MAX_BYTES,
                    )
                except Exception:
                    product_image_bytes = None

            screenshot_bytes: bytes | None = None
            if want_screenshot:
                try:
                    # Screenshot ONLY the product portal.
                    # User requirement: capture only id="ppd".
                    product_root = page.locator('#ppd').first
                    if await product_root.count() > 0:
                        with suppress(Exception):
                            await product_root.scroll_into_view_if_needed(timeout=min(4000, nav_timeout_ms))
                        screenshot_bytes = await product_root.screenshot(type='png')
                    else:
                        # Fallback (layout differences). Keep behavior safe instead of failing silently.
                        screenshot_bytes = await page.screenshot(full_page=True, type='png')

                    # Size guard: if full-page is too large, fall back to viewport capture.
                    if screenshot_bytes and len(screenshot_bytes) > SCRAPE_SCREENSHOT_MAX_BYTES:
                        with suppress(Exception):
                            screenshot_bytes = await page.screenshot(full_page=False, type='png')
                        if screenshot_bytes and len(screenshot_bytes) > SCRAPE_SCREENSHOT_MAX_BYTES:
                            screenshot_bytes = None
                except Exception:
                    screenshot_bytes = None

            return {
                'title': title,
                'price': deal_price,
                'mrp': regular_price,
                'image_bytes': product_image_bytes,
                'screenshot_bytes': screenshot_bytes,
            }
        finally:
            with suppress(Exception):
                await context.close()
            with suppress(Exception):
                await browser.close()


def _download_image_bytes(url: str, timeout_seconds: float, max_bytes: int) -> bytes:
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36',
        'Accept': 'image/avif,image/webp,image/apng,image/*,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
        'Referer': 'https://www.amazon.com/',
    }
    resp = requests.get(url, stream=True, timeout=timeout_seconds, headers=headers)
    resp.raise_for_status()

    chunks: list[bytes] = []
    total = 0
    for chunk in resp.iter_content(chunk_size=64 * 1024):
        if not chunk:
            continue
        total += len(chunk)
        if total > max_bytes:
            raise ValueError(f"Image too large ({total} bytes)")
        chunks.append(chunk)
    return b''.join(chunks)

# Channels to monitor
CHANNELS_TO_MONITOR = [
    1315464303,  # Offerzone 2.0
    1357275556,  # Offerzone
    1217577317,  # Dealdost
    1707571730,  # Offerzone 3.0
    1702197669,  # Offerzone Tricks
    2393042058,  # Offerzone 4.0
    '@Deals_Offerzone_Loots',  # Offerzone (public)
    2518292194,  # BIG LOOT
    1678712638,  # ProlooterZ Deals
    1825655180,  # Crazy Deals ™
    2248675730,  # Shop Smartly - Flipkart Big Festive Dhamaka Sale Best Deals & Offers
]

class ChannelMonitor:
    """Monitor multiple channels and print notifications"""
    
    def __init__(self):
        self.client = TelegramClient(_session_path(SESSION_BASE_NAME), api_id, api_hash)
        self.channel_names = {}
        self.forward_enabled = FORWARD_ENABLED_DEFAULT
        self.forward_target = FORWARD_TARGET_DEFAULT
        self.forward_mode = FORWARD_MODE_DEFAULT
        self.forward_original_message = FORWARD_ORIGINAL_MESSAGE_DEFAULT
        self.include_original_message_media = INCLUDE_ORIGINAL_MESSAGE_MEDIA_DEFAULT
        self._forward_target_entity_id: int | None = None
        self.scrape_and_send = SCRAPE_AND_SEND_DEFAULT
        self.scrape_send_image = SCRAPE_SEND_IMAGE_DEFAULT
        self.scrape_engine = SCRAPE_ENGINE_DEFAULT
        self.scrape_include_screenshot = SCRAPE_INCLUDE_SCREENSHOT_DEFAULT

        if IS_TERMUX and (self.scrape_engine or '').lower() == 'playwright':
            logger.warning("Playwright is not supported on Termux; forcing scrape_engine='requests' and disabling screenshots.")
            self.scrape_engine = 'requests'
            self.scrape_include_screenshot = False

        if IS_TERMUX and self.scrape_include_screenshot:
            logger.warning('Screenshots are disabled on Termux; forcing scrape_include_screenshot=false.')
            self.scrape_include_screenshot = False
        self._scrape_cache: dict[str, dict[str, str]] = {}
        self._instance_lock_fp: Any = None
        self._stop_event = asyncio.Event()
        self.stop_file = STOP_FILE

    def request_stop(self, reason: str | None = None) -> None:
        if reason:
            logger.info(f"Soft stop requested: {reason}")
        else:
            logger.info("Soft stop requested")
        self._stop_event.set()

    async def _stopper(self) -> None:
        await self._stop_event.wait()
        with suppress(Exception):
            await self.client.disconnect()

    async def _watch_stop_file(self) -> None:
        while not self._stop_event.is_set():
            try:
                if self.stop_file.exists():
                    logger.info(f"Soft stop flag detected: {self.stop_file}")
                    with suppress(Exception):
                        self.stop_file.unlink()
                    self._stop_event.set()
                    return
            except Exception as e:
                logger.warning(f"Stop-file watcher error: {e}")

            await asyncio.sleep(STOP_POLL_SECONDS)

    async def _start_once(self) -> None:
        await self.client.start()
        logger.info("✅ Connected to Telegram successfully")

        await self._configure_forwarding()

        channels_spec = _get_channels_to_monitor()
        channels_resolved = [_chat_spec_to_input(x) for x in channels_spec]

        # Get channel names
        print("\n" + "=" * 80)
        print("  🔔 TELEGRAM CHANNEL NOTIFICATION MONITOR")
        print("=" * 80)
        print("\n📡 Monitoring Channels:")
        print("-" * 80)

        for idx, channel_id in enumerate(channels_resolved, 1):
            try:
                entity = await self.client.get_entity(channel_id)
                channel_name = getattr(entity, 'title', 'Unknown')
                entity_id = getattr(entity, 'id', None)
                key = int(entity_id) if entity_id is not None else str(channel_id)
                self.channel_names[key] = channel_name
                print(f"{idx}. {channel_name} (ID: {channel_id})")
            except Exception as e:
                print(f"{idx}. ❌ Error accessing channel {channel_id}: {e}")

        print("-" * 80)
        print("\n🚀 Now monitoring for new messages... (Press Ctrl+C to stop)")
        print("=" * 80)
        print()

        # Register event handler for new messages from all monitored channels
        @self.client.on(events.NewMessage(chats=channels_resolved))
        async def handler(event):
            await self.handle_new_message(event)
            try:
                message = getattr(event, 'message', None)
                amazon_url = _first_amazon_url_for_message(message) if message else None

                msg_text = (getattr(message, 'message', None) or getattr(message, 'text', None) or '') if message else ''
                extracted = _extract_price_discount_from_text(str(msg_text) if msg_text else '')
                msg_price = extracted.get('price')
                msg_discount = extracted.get('discount')
                msg_mrp = extracted.get('mrp')
                msg_saved = extracted.get('saved')

                if amazon_url and self.forward_enabled and self.forward_original_message:
                    await self._forward_event_message(event, amazon_url=amazon_url)

                if amazon_url and self.scrape_and_send:
                    asyncio.create_task(
                        self._scrape_and_send_info(
                            amazon_url,
                            msg_price=msg_price,
                            msg_discount=msg_discount,
                            msg_mrp=msg_mrp,
                            msg_saved=msg_saved,
                            original_message=message,
                        )
                    )
            except Exception as e:
                logger.error(f"Forwarding error: {e}")

        # Keep the client running (until disconnected or soft-stop requested)
        stopper_task = asyncio.create_task(self._stopper())
        watch_task = asyncio.create_task(self._watch_stop_file())
        try:
            await self.client.run_until_disconnected()
        finally:
            for t in (watch_task, stopper_task):
                t.cancel()
            with suppress(Exception):
                await watch_task
            with suppress(Exception):
                await stopper_task

    async def _configure_forwarding(self) -> None:
        if not self.forward_enabled:
            return
        if not self.forward_target:
            logger.warning("Forwarding enabled but no forward_target_channel_id configured in config.json")
            self.forward_enabled = False
            return
        try:
            target_entity = await self.client.get_entity(self.forward_target)
            self._forward_target_entity_id = int(getattr(target_entity, 'id', 0) or 0) or None
            logger.info(f"📤 Forwarding enabled -> {getattr(target_entity, 'title', self.forward_target)}")
        except Exception as e:
            logger.error(f"Failed to resolve forward target {self.forward_target}: {e}")
            self.forward_enabled = False

    async def _scrape_and_send_info(
        self,
        amazon_url: str,
        msg_price: str | None = None,
        msg_discount: str | None = None,
        msg_mrp: str | None = None,
        msg_saved: str | None = None,
        original_message=None,
    ) -> None:
        if not self.scrape_and_send:
            return
        if not self.forward_target:
            return

        if self.scrape_include_screenshot and (self.scrape_engine or '').lower() != 'playwright':
            logger.info("Screenshot requested but scrape_engine is not 'playwright' (set it to enable full-page screenshots).")

        try:
            cached = self._scrape_cache.get(amazon_url)
            if cached is None:
                data = await asyncio.to_thread(_scrape_amazon_product, amazon_url, SCRAPE_TIMEOUT_SECONDS)
                self._scrape_cache[amazon_url] = data
            else:
                data = cached
        except Exception as e:
            logger.error(f"Scrape failed for {amazon_url}: {e}")
            return

        if not data:
            return

        title = (data.get('title') or '').strip()
        mrp = (data.get('mrp') or msg_mrp or '').strip()
        price_after = (data.get('price') or msg_price or '').strip()
        saved = (msg_saved or '').strip()

        if not saved:
            mrp_val = _parse_inr_amount(mrp)
            price_val = _parse_inr_amount(price_after)
            if mrp_val is not None and price_val is not None and mrp_val >= price_val:
                fmt = _format_inr(mrp_val - price_val)
                if fmt:
                    saved = fmt

        # If configured, do a Playwright scrape for exact product image + full-page screenshot + better prices.
        product_image_bytes: bytes | None = None
        screenshot_bytes: bytes | None = None
        if (self.scrape_engine or '').lower() == 'playwright':
            try:
                pw = await _scrape_amazon_product_playwright(
                    amazon_url,
                    timeout_seconds=SCRAPE_TIMEOUT_SECONDS,
                    want_screenshot=self.scrape_include_screenshot,
                )
                if isinstance(pw.get('title'), str) and pw.get('title'):
                    title = str(pw['title']).strip()
                if isinstance(pw.get('price'), str) and pw.get('price'):
                    price_after = str(pw['price']).strip()
                if isinstance(pw.get('mrp'), str) and pw.get('mrp'):
                    mrp = str(pw['mrp']).strip()
                product_image_bytes = pw.get('image_bytes') if isinstance(pw.get('image_bytes'), (bytes, type(None))) else None
                screenshot_bytes = pw.get('screenshot_bytes') if isinstance(pw.get('screenshot_bytes'), (bytes, type(None))) else None
            except Exception as e:
                logger.warning(f"Playwright scrape unavailable/failed; falling back: {e}")

        # Build caption in the exact requested deal template.
        deal_fmt = _format_inr_caption_style(price_after)
        mrp_fmt = _format_inr_caption_style(mrp)

        plain_lines: list[str] = []
        html_lines: list[str] = []

        if title:
            plain_lines.append(title)
            html_lines.append(f"<b>{html.escape(title)}</b>")

        if deal_fmt:
            plain_lines.append(f"✅ Deal Price: {deal_fmt} 😱")
            html_lines.append(html.escape(f"✅ Deal Price: {deal_fmt} 😱"))

        if mrp_fmt:
            plain_lines.append(f"❌ Regular Price: {mrp_fmt} 🙅")
            html_lines.append(f"❌ Regular Price: <s>{html.escape(mrp_fmt)}</s> 🙅")

        href = html.escape(amazon_url, quote=True)
        # Plain-text fallback can't embed hyperlinks; keep the URL there only as fallback.
        plain_lines.append(f"🛒 Buy Now: {amazon_url}")
        html_lines.append(f'🛒 <a href="{href}">Buy Now</a>')

        # Use blank lines between sections.
        info_text = "\n\n".join([x for x in plain_lines if x]).strip()
        info_html = "\n\n".join([x for x in html_lines if x]).strip()
        if not info_text:
            return

        image_url = (data.get('image_url') or '').strip()

        # Original image from message (optional)
        original_bio: BytesIO | None = None
        if self.include_original_message_media and original_message is not None and getattr(original_message, 'media', None):
            try:
                file_obj = getattr(original_message, 'file', None)
                size = getattr(file_obj, 'size', None)
                if isinstance(size, int) and size > MESSAGE_IMAGE_MAX_BYTES:
                    logger.info(f"Skipping original media; size {size} > {MESSAGE_IMAGE_MAX_BYTES}")
                else:
                    original_bio = BytesIO()
                    original_bio.name = 'original.jpg'
                    await self.client.download_media(original_message, file=original_bio)
                    original_bio.seek(0)
            except Exception as e:
                logger.warning(f"Failed to download original message media: {e}")
                original_bio = None

        try:
            files_to_send: list[BytesIO] = []

            # Order requirement: product image first, then full-page screenshot.
            # (Optional) original message media goes last if enabled.
            if product_image_bytes and self.scrape_send_image:
                bio = BytesIO(product_image_bytes)
                bio.name = 'product.jpg'
                files_to_send.append(bio)
            elif image_url and self.scrape_send_image:
                try:
                    img_bytes = await asyncio.to_thread(
                        _download_image_bytes,
                        image_url,
                        min(SCRAPE_TIMEOUT_SECONDS, 15.0),
                        SCRAPE_IMAGE_MAX_BYTES,
                    )
                    bio = BytesIO(img_bytes)
                    bio.name = 'amazon.jpg'
                    files_to_send.append(bio)
                except Exception as e:
                    logger.warning(f"Failed to download Amazon image for {amazon_url}: {e}")

            if screenshot_bytes:
                bio = BytesIO(screenshot_bytes)
                bio.name = 'page.png'
                files_to_send.append(bio)

            if original_bio is not None:
                files_to_send.append(original_bio)

            if files_to_send:
                caption = info_html or info_text
                if len(caption) > 900:
                    caption = caption[:897] + '...'
                await self.client.send_file(
                    entity=self.forward_target,
                    file=files_to_send,
                    caption=caption,
                    parse_mode='html',
                )
                return

            await self.client.send_message(entity=self.forward_target, message=(info_html or info_text), parse_mode='html')
        except Exception as e:
            logger.error(f"Failed to send scrape info to {self.forward_target}: {e}")


    async def _forward_event_message(self, event, amazon_url: str | None = None) -> str | None:
        if not self.forward_enabled:
            return None

        # Avoid loops if your target is also in monitored list.
        try:
            if self._forward_target_entity_id is not None and getattr(event, 'chat_id', None) == self._forward_target_entity_id:
                return
        except Exception:
            pass

        message = event.message
        if not message:
            return None

        # Only allow sending messages that contain an Amazon URL.
        amazon_url = amazon_url or _first_amazon_url_for_message(message)
        if not amazon_url:
            return None

        message_id = getattr(message, 'id', None)

        try:
            if (self.forward_mode or 'copy').lower() == 'forward':
                await self.client.forward_messages(entity=self.forward_target, messages=message)
                logger.info(f"📤 Forwarded message {message_id} -> {self.forward_target}")
                return amazon_url

            # copy mode: do not change message content/formatting.
            text = getattr(message, 'message', None) or ''
            entities = getattr(message, 'entities', None)

            if getattr(message, 'media', None):
                # Re-send the original message media; keeps caption text/entities unchanged.
                await self.client.send_file(
                    entity=self.forward_target,
                    file=message,
                    caption=text if text else None,
                    formatting_entities=entities,
                    parse_mode=None,
                )
            else:
                if not text:
                    return
                await self.client.send_message(
                    entity=self.forward_target,
                    message=text,
                    formatting_entities=entities,
                    parse_mode=None,
                )

            logger.info(f"📤 Copied message {message_id} -> {self.forward_target}")
            return amazon_url
        except Exception as e:
            logger.error(f"Forwarding error to {self.forward_target}: {e}")
            return None
        
    async def start(self):
        """Start monitoring channels"""
        if self._instance_lock_fp is None:
            self._instance_lock_fp = _acquire_single_instance_lock()

        retries = int(config.get('session_lock_retries', 6))
        delay = float(config.get('session_lock_retry_delay_seconds', 2.0))

        last_exc: BaseException | None = None
        for attempt in range(1, retries + 1):
            try:
                await self._start_once()
                return
            except BaseException as e:
                if not _is_db_locked_error(e):
                    logger.error(f"Error starting monitor: {e}")
                    raise

                last_exc = e
                logger.error(
                    "Telethon session database is locked. "
                    "This usually means another Telegram process is using the session, or the OS temporarily locked the file. "
                    f"Retrying ({attempt}/{retries}) in {delay:.1f}s..."
                )
                with suppress(Exception):
                    await self.client.disconnect()

                if attempt >= retries:
                    break

                await asyncio.sleep(delay)
                delay = min(delay * 2, 30.0)
                # Recreate client to ensure a clean session handle
                self.client = TelegramClient(_session_path(SESSION_BASE_NAME), api_id, api_hash)

        if last_exc is not None:
            raise last_exc
    
    async def handle_new_message(self, event):
        """Handle and display new messages"""
        try:
            message = event.message
            chat = await event.get_chat()
            channel_name = getattr(chat, 'title', 'Unknown Channel')
            
            # Get message timestamp
            timestamp = message.date.strftime('%Y-%m-%d %H:%M:%S')
            
            # Print separator
            print("\n" + "┌" + "─" * 78 + "┐")
            
            # Print channel name and time
            print(f"│ 📢 {channel_name:<50} │ 🕒 {timestamp} │")
            print("├" + "─" * 78 + "┤")
            
            # Extract title from message (first line usually contains the title)
            title = "No Title"
            if message.text:
                lines = message.text.strip().split('\n')
                # Get first non-empty line as title, remove markdown formatting
                for line in lines:
                    clean_line = re.sub(r'\*+|_+|~+', '', line).strip()
                    if clean_line and len(clean_line) > 5:
                        title = clean_line[:100]  # Limit title length
                        break
            
            # Print title
            title_lines = self.wrap_text(f"📝 {title}", 76)
            for line in title_lines:
                print(f"│ {line:<76} │")
            
            # Extract and expand URLs
            expanded_urls = self.extract_and_expand_urls(message.text)
            
            if expanded_urls:
                print("├" + "─" * 78 + "┤")
                print(f"│ 🔗 PRODUCT LINKS:                                                      │")
                print("├" + "─" * 78 + "┤")
                
                for idx, url_info in enumerate(expanded_urls, 1):
                    full_url = url_info['expanded']
                    
                    # Check if it's an Amazon link with our tag
                    is_amazon = 'amazon' in full_url.lower() or 'amzn' in full_url.lower()
                    tag_indicator = " 💰" if is_amazon and 'localseller0b-21' in full_url else ""
                    
                    # Print URL with number
                    print(f"│ {idx}. {full_url[:73]}{tag_indicator:<3}│")
                    
                    # If URL is longer, print continuation
                    if len(full_url) > 73:
                        remaining = full_url[73:]
                        chunks = [remaining[i:i+76] for i in range(0, len(remaining), 76)]
                        for chunk in chunks:
                            print(f"│    {chunk:<74} │")
            else:
                # No URLs found
                print("├" + "─" * 78 + "┤")
                print(f"│ ℹ️  No links found in this message                                     │")
            
            # Print bottom separator
            print("└" + "─" * 78 + "┘")
            
            # Log to file
            logger.info(f"New message from {channel_name}: {title[:50]}...")
            
        except Exception as e:
            logger.error(f"Error handling message: {e}")
    
    def wrap_text(self, text, width):
        """Wrap text to fit console width"""
        if not text:
            return []
        
        lines = []
        for paragraph in text.split('\n'):
            if not paragraph:
                lines.append('')
                continue
                
            words = paragraph.split()
            current_line = ''
            
            for word in words:
                if len(current_line) + len(word) + 1 <= width:
                    current_line += (' ' if current_line else '') + word
                else:
                    if current_line:
                        lines.append(current_line)
                    current_line = word
            
            if current_line:
                lines.append(current_line)
        
        return lines if lines else ['']
    
    def expand_url(self, short_url):
        """Expand shortened URL to get the actual destination"""
        try:
            # Common URL shorteners
            shorteners = ['bit.ly', 'tinyurl.com', 'goo.gl', 'amzn.to', 'fkrt.it', 
                         't.co', 'ow.ly', 'buff.ly', 'is.gd', 'cutt.ly', 'rebrand.ly',
                         'short.link', 'tiny.cc', 'clk.sh', 'rb.gy', 'dl.flipkart.com']
            
            # Check if URL contains a shortener
            is_shortened = any(shortener in short_url.lower() for shortener in shorteners)
            
            if is_shortened:
                # Follow redirects to get final URL
                req = urllib.request.Request(short_url, method='HEAD')
                req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
                
                with urllib.request.urlopen(req, timeout=5) as response:
                    final_url = response.url
                    
                    # Replace Amazon affiliate tag
                    final_url = self.replace_amazon_tag(final_url)
                    
                    return final_url
            else:
                # Even if not shortened, check for Amazon links
                return self.replace_amazon_tag(short_url)
            
            return short_url
            
        except Exception as e:
            # If expansion fails, return original URL
            return short_url
    
    def replace_amazon_tag(self, url):
        """Replace Amazon affiliate tag with localseller0b-21"""
        if not url:
            return url
        
        # Check if it's an Amazon URL
        amazon_domains = ['amazon.in', 'amazon.com', 'amzn.to', 'amzn.in']
        is_amazon = any(domain in url.lower() for domain in amazon_domains)
        
        if is_amazon:
            # Replace tag parameter
            # Pattern: tag=anything or tag=anything&
            import re
            
            # Remove existing tag parameter
            url = re.sub(r'[?&]tag=[^&]*', '', url)
            
            # Add our tag
            separator = '&' if '?' in url else '?'
            url = f"{url}{separator}tag=localseller0b-21"
        
        return url
    
    def extract_and_expand_urls(self, text):
        """Extract URLs from text and expand them"""
        if not text:
            return []
        
        # Regex to find URLs
        url_pattern = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
        urls = re.findall(url_pattern, text)
        
        expanded_urls = []
        for url in urls:
            expanded = self.expand_url(url)
            if expanded != url:
                expanded_urls.append({
                    'short': url,
                    'expanded': expanded
                })
        
        return expanded_urls
    
    async def stop(self):
        """Stop the monitor"""
        logger.info("Stopping channel monitor...")
        self._stop_event.set()
        with suppress(Exception):
            await self.client.disconnect()
        _release_single_instance_lock(self._instance_lock_fp)
        self._instance_lock_fp = None
        logger.info("Monitor stopped")


async def main():
    """Main entry point"""
    monitor = ChannelMonitor()

    def _signal_handler(signum, _frame):
        name = getattr(signal, 'Signals', None)
        try:
            sig_name = signal.Signals(signum).name  # type: ignore[attr-defined]
        except Exception:
            sig_name = str(signum)
        monitor.request_stop(f"signal {sig_name}")
    
    try:
        with suppress(Exception):
            signal.signal(signal.SIGTERM, _signal_handler)
        with suppress(Exception):
            signal.signal(signal.SIGBREAK, _signal_handler)  # Windows console close/break
        await monitor.start()
    except KeyboardInterrupt:
        print("\n\n" + "=" * 80)
        print("  👋 Stopping monitor...")
        print("=" * 80)
    except Exception as e:
        if isinstance(e, PermissionError):
            logger.error(f"Fatal error: [Errno 13] Permission denied: {getattr(e, 'filename', '')}")
        else:
            logger.error(f"Fatal error: {e}")
        logger.exception("Fatal error details")
    finally:
        await monitor.stop()


if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("  Telegram Channel Monitor - Real-time Notifications")
    print("=" * 80)
    print()
    
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n\n👋 Monitor stopped by user")
    except Exception as e:
        print(f"\n❌ Error: {e}")
