# AutoAppnt Linux One-Click Bundle (Ubuntu, 24/7)

This bundle is designed to run `monitor_channels.py` continuously on a Linux machine.

## Quick start (recommended: systemd user service)

1) Copy this folder to `~/autoappnt`

2) Setup Python deps:

```bash
cd ~/autoappnt
# Optional (installs Ubuntu packages):
# AUTOAPPNT_APT=1 bash setup.sh

bash setup.sh

# If you want screenshots (Playwright):
# AUTOAPPNT_FULL=1 AUTOAPPNT_INSTALL_PLAYWRIGHT_BROWSERS=1 bash setup.sh
```

3) Edit config:

- `config.json` (set `api_id`, `api_hash`, `forward_target_channel_id`, etc.)

4) Start as a 24/7 service:

```bash
bash install-user-service.sh
```

5) Follow logs:

```bash
journalctl --user -u autoappnt-monitor.service -f
```

## Keep running after logout

For a *user* service to run without an active login session:

```bash
sudo loginctl enable-linger $USER
```

## Stop gracefully

```bash
bash stop.sh
```

Or:

```bash
python soft_stop_monitoring.py
```

## Enable screenshots (optional)

1) Install Playwright + Chromium:

```bash
cd ~/autoappnt
AUTOAPPNT_FULL=1 AUTOAPPNT_INSTALL_PLAYWRIGHT_BROWSERS=1 bash setup.sh
```

2) In `config.json` set:

- `"scrape_engine": "playwright"`
- `"scrape_include_screenshot": true`

## Alternative (no systemd): run-forever loop

```bash
cd ~/autoappnt
bash run-forever.sh
```

Consider running that inside `tmux`:

```bash
sudo apt-get install -y tmux
tmux new -s autoappnt
bash run-forever.sh
```
