# AutoAppnt Linux One-Click Bundle (Ubuntu, 24/7)

This bundle is designed to run `monitor_channels.py` continuously on a Linux machine.

## Quick start (recommended: systemd user service)

### One command (Ubuntu)

If this folder is located at `~/autoappnt`, you can deploy almost everything with:

```bash
cd ~/autoappnt
bash oneclick-ubuntu.sh
```

It will **not** start the service until `config.json` contains real `api_id`/`api_hash`.

If `systemd` is not available (common in **mobile Ubuntu** like UserLAnd / PRoot), it will automatically fall back to a `tmux`-based runner.

### Manual steps

1) Copy this folder to `~/autoappnt`

2) Setup Python deps:

```bash
cd ~/autoappnt
# Optional (installs Ubuntu packages):
# AUTOAPPNT_APT=1 bash setup.sh

bash setup.sh

# Playwright (recommended for scraping screenshots):
# AUTOAPPNT_SCRAPER=1 AUTOAPPNT_INSTALL_PLAYWRIGHT_BROWSERS=1 bash setup.sh
```

3) Edit config:

- `config.json` (set `api_id`, `api_hash`, `forward_target_channel_id`, etc.)

4) Start as a 24/7 service:

```bash
bash install-user-service.sh
```

5) Follow logs:

```bash
journalctl --user -u autoappnt-monitor.service -f
```

## Keep running after logout

For a *user* service to run without an active login session:

```bash
sudo loginctl enable-linger $USER
```

## Stop gracefully

```bash
bash stop.sh
```

Or:

```bash
python soft_stop_monitoring.py
```

## Enable screenshots (optional)

1) Install Playwright + Chromium:

```bash
cd ~/autoappnt
AUTOAPPNT_SCRAPER=1 AUTOAPPNT_INSTALL_PLAYWRIGHT_DEPS=1 AUTOAPPNT_INSTALL_PLAYWRIGHT_BROWSERS=1 bash setup.sh
```

2) In `config.json` set:

- `"scrape_engine": "playwright"`
- `"scrape_include_screenshot": true`

## Run scraper scripts (optional)

The bundle includes these helpers:

- `amazon_scraper.py`
- `amazon_scraper_simple.py`
- `amazon_scraper_playwright.py`

Example:

```bash
cd ~/autoappnt
source .venv/bin/activate
python amazon_scraper_simple.py
```

## Alternative (no systemd): run-forever loop

```bash
cd ~/autoappnt
bash run-forever.sh
```

Consider running that inside `tmux`:

```bash
sudo apt-get install -y tmux
tmux new -s autoappnt
bash run-forever.sh
```

## Mobile Ubuntu notes (Android/UserLAnd/PRoot)

On mobile Ubuntu environments, `systemctl` often doesn't work. Use tmux mode:

```bash
cd ~/autoappnt
bash start-tmux.sh
```

Stop:

```bash
cd ~/autoappnt
bash stop-tmux.sh
```

Autostart on phone reboot depends on your host app (often done via Termux:Boot if you're using Termux + Ubuntu PRoot).

### Playwright troubleshooting (mobile)

- Playwright works best on `x86_64` and `aarch64`.
- If Chromium fails to launch, try re-running setup with deps:
  `AUTOAPPNT_SCRAPER=1 AUTOAPPNT_INSTALL_PLAYWRIGHT_DEPS=1 AUTOAPPNT_INSTALL_PLAYWRIGHT_BROWSERS=1 bash setup.sh`
