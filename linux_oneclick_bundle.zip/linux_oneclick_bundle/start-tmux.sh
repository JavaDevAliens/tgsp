#!/usr/bin/env bash

if [ -z "${BASH_VERSION:-}" ]; then
  if command -v bash >/dev/null 2>&1; then
    exec bash "$0" "$@"
  fi
  echo "ERROR: bash is required to run this script." >&2
  exit 1
fi

set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$APP_DIR"

SESSION_NAME="autoappnt"
LOG_FILE="$APP_DIR/channel_monitor_mobile.log"

if ! command -v tmux >/dev/null 2>&1; then
  echo "[autoappnt] tmux not found. Installing (Ubuntu/Debian)..." 
  if command -v apt-get >/dev/null 2>&1; then
    sudo apt-get update
    sudo apt-get install -y tmux
  else
    echo "ERROR: tmux not installed and apt-get not available." >&2
    exit 1
  fi
fi

if tmux has-session -t "$SESSION_NAME" 2>/dev/null; then
  echo "[autoappnt] tmux session already running: $SESSION_NAME"
  echo "Attach: tmux attach -t $SESSION_NAME"
  exit 0
fi

echo "[autoappnt] Starting monitor in tmux session: $SESSION_NAME"
tmux new-session -d -s "$SESSION_NAME" "bash run-forever.sh >> \"$LOG_FILE\" 2>&1"

echo "[autoappnt] Logs: $LOG_FILE"
echo "[autoappnt] Attach: tmux attach -t $SESSION_NAME"
