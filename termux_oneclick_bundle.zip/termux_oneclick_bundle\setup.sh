#!/data/data/com.termux/files/usr/bin/bash
set -eu

echo "[autoappnt] One-click setup starting..."

# Basic packages
pkg update -y
pkg install -y python python-pip git tmux termux-api nano openssl

# Python deps (do NOT upgrade pip on Termux; it's managed by pkg)
python -m pip install --no-cache-dir -r requirements_termux.txt

# Create session dir and helper path file
mkdir -p "$HOME/.local/state/autoappnt/telethon_sessions"

# Config
if [ ! -f config.json ]; then
  echo "[autoappnt] Creating config.json from template..."
  cp -f config.json.termux config.json
  echo "[autoappnt] Edit config.json now (api_id/api_hash/forward_target_channel_id)."
fi

# Boot script (requires Termux:Boot app installed)
mkdir -p "$HOME/.termux/boot"
cat > "$HOME/.termux/boot/autoappnt-start.sh" <<'EOF'
#!/data/data/com.termux/files/usr/bin/bash
set -eu

# Change directory to this bundle if it still exists in HOME
BUNDLE_DIR="$HOME/autoappnt"
if [ -d "$BUNDLE_DIR" ]; then
  cd "$BUNDLE_DIR"
fi

# Start in tmux
bash start.sh
EOF
chmod +x "$HOME/.termux/boot/autoappnt-start.sh"

# Keep awake (requires Termux:API app installed)
termux-wake-lock || true

echo ""
echo "[autoappnt] Setup complete."
echo "Next:" 
echo "  1) Edit config.json" 
echo "  2) Run: bash start.sh" 
echo "To stop: bash stop.sh" 
