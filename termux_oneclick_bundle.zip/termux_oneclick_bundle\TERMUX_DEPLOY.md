This file is kept for convenience.

See the canonical Termux deployment guide: `termux/TERMUX_DEPLOY.md`

## 1) Install Termux + setup

- Install **Termux** (prefer F-Droid build)
- Open Termux and run:

```sh
pkg update -y
pkg upgrade -y
pkg install -y python git openssl
python -m pip install --upgrade pip
```

Optional but recommended for long-running monitoring:

```sh
pkg install -y tmux
termux-wake-lock
```

## 2) Get the code on your phone

Clone (recommended):

```sh
git clone <YOUR_REPO_URL_OR_COPY_FOLDER> autoappnt
cd autoappnt
```

If you copied the folder manually, just `cd` into it:

```sh
cd ~/autoappnt
```

## 3) Install Python dependencies

For the Telegram monitor:

```sh
python -m pip install -r requirements_termux.txt
```

If you also use the Amazon scraper:

```sh
python -m pip install -r requirements_scraper.txt
```

## 4) Create config

Make sure `config.json` exists in the project directory.

Example keys needed for Telegram:

```json
{
  "api_id": 123456,
  "api_hash": "...",
  "monitor_session_name": "channel_monitor_session",
  "channels_to_monitor_file": "channels_to_monitor.json"
}
```

Notes:
- The script will prompt you for **phone** and **login code** the first time.
- Sessions are stored under your Termux home in an XDG folder (e.g. `~/.local/state/autoappnt/telethon_sessions/`).

## 5) Refresh channel IDs (recommended)

This generates/updates `channels_to_monitor.json` with the correct IDs/access hashes:

```sh
python monitor_channels.py --refresh
```

## 6) Run the monitor

Foreground:

```sh
python monitor_channels.py
```

Background (recommended):

```sh
tmux new -s monitor
python monitor_channels.py
```

Detach from tmux with `Ctrl+b` then `d`.
Reattach:

```sh
tmux attach -t monitor
```

### Soft stop (graceful shutdown)

If the monitor is running in another terminal/tmux session, you can request a graceful stop by creating a stop-flag file:

```sh
python soft_stop_monitoring.py
```

By default this creates `monitor.stop` (configurable via `monitor_stop_file` in `config.json`).

## Troubleshooting

### “database is locked”

- You started the monitor twice (two processes using the same session)
- Or session file lives in a synced folder

Fix:
- Stop other running Telegram scripts
- Or set a unique `monitor_session_name` in `config.json`

### Flood waits

If you use `--refresh-all`, Telegram may rate-limit username resolving. Prefer `--refresh`.
