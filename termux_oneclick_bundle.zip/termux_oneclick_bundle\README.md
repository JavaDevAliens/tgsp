# AutoAppnt Termux One-Click Bundle

## Quick start

1. Copy this whole folder to Termux home as `~/autoappnt`
   - Example: put it in Downloads, then in Termux run:
     - `cp -r /sdcard/Download/termux_oneclick_bundle $HOME/autoappnt`

2. In Termux:
   - `cd $HOME/autoappnt`
   - `bash setup.sh`
   - Edit `config.json`
   - `bash start.sh`

## Notes
- This uses `tmux`, so it keeps running when you close Termux.
- Boot auto-start requires the **Termux:Boot** app and enabling it.
- Playwright/Chromium screenshots are not supported reliably on Termux; this bundle uses `requests` scraping.
