#!/data/data/com.termux/files/usr/bin/bash
set -eu

while true; do
  echo "[autoappnt] Starting monitor: $(date)"
  python monitor_channels.py || true
  echo "[autoappnt] Monitor exited. Restarting in 5s..."
  sleep 5
done
