"""Soft-stop helper for monitor_channels.py.

This script creates (or clears) the stop-flag file that the monitor watches.

Usage:
  python soft_stop_monitoring.py          # request soft stop
  python soft_stop_monitoring.py --clear  # remove stop flag
  python soft_stop_monitoring.py --path monitor.stop
"""

from __future__ import annotations

import argparse
import json
from datetime import datetime
from pathlib import Path


def _default_stop_file() -> Path:
    cfg = Path('config.json')
    if cfg.exists():
        try:
            data = json.loads(cfg.read_text(encoding='utf-8'))
            p = data.get('monitor_stop_file')
            if isinstance(p, str) and p.strip():
                return Path(p.strip())
        except Exception:
            pass
    return Path('monitor.stop')


def main() -> int:
    parser = argparse.ArgumentParser(description='Request a graceful stop of monitor_channels.py')
    parser.add_argument('--clear', action='store_true', help='Remove the stop flag (if present)')
    parser.add_argument('--path', type=str, default=None, help='Stop-flag file path (overrides config)')
    args = parser.parse_args()

    stop_file = Path(args.path) if args.path else _default_stop_file()

    if args.clear:
        if stop_file.exists():
            stop_file.unlink()
            print(f'Cleared stop flag: {stop_file.resolve()}')
        else:
            print(f'No stop flag present: {stop_file.resolve()}')
        return 0

    stop_file.parent.mkdir(parents=True, exist_ok=True)
    stop_file.write_text(f'stop requested at {datetime.now().isoformat()}\n', encoding='utf-8')
    print(f'Soft stop requested. Created: {stop_file.resolve()}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
