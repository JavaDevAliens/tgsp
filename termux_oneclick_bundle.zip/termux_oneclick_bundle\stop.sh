#!/data/data/com.termux/files/usr/bin/bash
set -eu

# Soft stop flag (monitor watches for this file in its working directory)
touch monitor.stop

echo "[autoappnt] Soft stop requested (monitor.stop created)."
