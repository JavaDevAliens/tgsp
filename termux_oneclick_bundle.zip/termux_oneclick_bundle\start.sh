#!/data/data/com.termux/files/usr/bin/bash
set -eu

SESSION_NAME="autoappnt-monitor"

if tmux has-session -t "$SESSION_NAME" 2>/dev/null; then
  echo "[autoappnt] tmux session already running: $SESSION_NAME"
  echo "Attach with: tmux attach -t $SESSION_NAME"
  exit 0
fi

# Run forever loop in tmux so Termux can be closed
LOG_FILE="channel_monitor_termux.log"

tmux new-session -d -s "$SESSION_NAME" "bash run-forever.sh >> \"$LOG_FILE\" 2>&1"

echo "[autoappnt] Started in tmux session: $SESSION_NAME"
echo "Logs: $LOG_FILE"
echo "Attach: tmux attach -t $SESSION_NAME"
